# Keep IME service and classes
-keep class com.ioskeyboard.vn.IOSKeyboardService { *; }
