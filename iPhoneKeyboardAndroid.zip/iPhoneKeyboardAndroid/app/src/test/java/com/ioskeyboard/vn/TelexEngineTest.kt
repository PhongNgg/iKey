package com.ioskeyboard.vn

import org.junit.Assert.assertEquals
import org.junit.Test

class TelexEngineTest {

    private fun typeWord(input: String): String {
        val engine = TelexEngine()
        var text = ""
        for (ch in input) {
            if (ch == '<') {
                val upd = engine.processBackspace()
                if (upd != null) {
                    text = text.dropLast(upd.deleteBeforeCursor) + upd.commitText
                }
            } else {
                val upd = engine.processLetter(ch)
                text = text.dropLast(upd.deleteBeforeCursor) + upd.commitText
            }
        }
        return text
    }

    @Test
    fun testBasicVietnameseWords() {
        assertEquals("ă", typeWord("aw"))
        assertEquals("ắ", typeWord("aws"))
        assertEquals("ắ", typeWord("asw"))
        assertEquals("việt", typeWord("vieetj"))
        assertEquals("tiếng", typeWord("tieengs"))
        assertEquals("người", typeWord("nguowif"))
        assertEquals("dương", typeWord("duowng"))
        assertEquals("dương", typeWord("duwong"))
        assertEquals("dương", typeWord("duwowng"))
        assertEquals("được", typeWord("dduowcj"))
        assertEquals("trường", typeWord("truwowngf"))
        assertEquals("không", typeWord("khoong"))
        assertEquals("tối", typeWord("toois"))
        assertEquals("đặt", typeWord("ddatwj"))
        assertEquals("mưa", typeWord("muaw"))
        assertEquals("sửa", typeWord("suawr"))
        assertEquals("quăn", typeWord("quawn"))
        assertEquals("đa", typeWord("dad"))
        assertEquals("tuyệt", typeWord("tuyeetj"))
        assertEquals("quyền", typeWord("quyeefn"))
        assertEquals("giữ", typeWord("giuwx"))
        assertEquals("hiểu", typeWord("hieeur"))
    }

    @Test
    fun testTonePlacementAndRepositioning() {
        assertEquals("hoà", typeWord("hoaf"))
        assertEquals("hoàn", typeWord("hoafn"))
        assertEquals("thuỷ", typeWord("thuyr"))
        assertEquals("quá", typeWord("quas"))
        assertEquals("giá", typeWord("gias"))
        assertEquals("báo", typeWord("baos"))
        assertEquals("múa", typeWord("muas"))
    }

    @Test
    fun testUndoAndZRemoveTone() {
        assertEquals("aa", typeWord("aaa"))
        assertEquals("as", typeWord("ass"))
        assertEquals("of", typeWord("off"))
        assertEquals("hoa", typeWord("hoafz"))
        assertEquals("ư", typeWord("w"))
        assertEquals("w", typeWord("ww"))
        assertEquals("tư", typeWord("tw"))
        assertEquals("từ", typeWord("twf"))
    }

    @Test
    fun testCasePreservationAndBackspace() {
        assertEquals("VIỆT", typeWord("VIEETJ"))
        assertEquals("Đà", typeWord("Ddaf"))
        assertEquals("Việt", typeWord("Vieetj"))
        assertEquals("việ", typeWord("vieetj<"))
    }
}
