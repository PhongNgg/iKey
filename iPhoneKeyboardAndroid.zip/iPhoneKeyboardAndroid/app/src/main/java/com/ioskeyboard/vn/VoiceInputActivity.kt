package com.ioskeyboard.vn

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.widget.Toast

/**
 * Shared one-shot buffer that safely delivers spoken text from VoiceInputActivity
 * back to IOSKeyboardService as soon as the target app regains input focus.
 */
object VoiceResultBus {
    @Volatile
    private var pendingText: String? = null
    @Volatile
    private var pendingUptime: Long = 0L

    @Volatile
    var onResultReady: (() -> Unit)? = null

    fun publish(text: String) {
        pendingText = text
        pendingUptime = SystemClock.uptimeMillis()
        onResultReady?.invoke()
    }

    fun consume(): String? {
        val text = pendingText ?: return null
        val age = SystemClock.uptimeMillis() - pendingUptime
        pendingText = null
        return if (age <= 15_000L) text else null
    }
}

/**
 * Lightweight translucent Activity that launches Android/Google's foreground
 * RecognizerIntent.ACTION_RECOGNIZE_SPEECH dialog (avoiding Android 12-15 background
 * microphone restrictions on InputMethodService).
 */
class VoiceInputActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val lang = intent.getStringExtra(EXTRA_LANG) ?: "vi-VN"
        val prompt = if (lang.startsWith("vi")) "Nói để nhập tiếng Việt..." else "Speak to type..."

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, prompt)
        }

        try {
            @Suppress("DEPRECATION")
            startActivityForResult(recognizerIntent, REQ_VOICE)
        } catch (_: Exception) {
            Toast.makeText(
                this,
                "Không tìm thấy dịch vụ nhận dạng giọng nói Google trên máy",
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }

    @Deprecated("Uses standard Activity result callback for translucent voice bridge")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK && data != null) {
            val spoken = data
                .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
            if (!spoken.isNullOrEmpty()) {
                VoiceResultBus.publish(spoken)
            }
        }
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    companion object {
        const val EXTRA_LANG = "extra_lang"
        private const val REQ_VOICE = 2001
    }
}
