package com.ioskeyboard.vn

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: KeyboardPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = KeyboardPrefs(this)

        findViewById<Button>(R.id.btnEnableKeyboard).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        findViewById<Button>(R.id.btnSelectKeyboard).setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        val swNumberRow = findViewById<SwitchCompat>(R.id.swNumberRow)
        val swTelex = findViewById<SwitchCompat>(R.id.swTelex)
        val swPopup = findViewById<SwitchCompat>(R.id.swPopup)
        val swHaptic = findViewById<SwitchCompat>(R.id.swHaptic)
        val swSound = findViewById<SwitchCompat>(R.id.swSound)
        val swDoubleSpace = findViewById<SwitchCompat>(R.id.swDoubleSpace)
        val rgTheme = findViewById<RadioGroup>(R.id.rgTheme)
        val rgHeight = findViewById<RadioGroup>(R.id.rgHeight)

        swNumberRow.isChecked = prefs.numberRowEnabled
        swTelex.isChecked = prefs.telexEnabled
        swPopup.isChecked = prefs.popupEnabled
        swHaptic.isChecked = prefs.hapticEnabled
        swSound.isChecked = prefs.soundEnabled
        swDoubleSpace.isChecked = prefs.doubleSpacePeriod

        rgTheme.check(
            when (prefs.themeMode) {
                KeyboardPrefs.THEME_LIGHT -> R.id.rbThemeLight
                KeyboardPrefs.THEME_DARK -> R.id.rbThemeDark
                else -> R.id.rbThemeAuto
            }
        )

        rgHeight.check(
            when (prefs.keyHeightDp) {
                38 -> R.id.rbHeightCompact
                46 -> R.id.rbHeightTall
                else -> R.id.rbHeightStandard
            }
        )

        swNumberRow.setOnCheckedChangeListener { _, checked -> prefs.numberRowEnabled = checked }
        swTelex.setOnCheckedChangeListener { _, checked -> prefs.telexEnabled = checked }
        swPopup.setOnCheckedChangeListener { _, checked -> prefs.popupEnabled = checked }
        swHaptic.setOnCheckedChangeListener { _, checked -> prefs.hapticEnabled = checked }
        swSound.setOnCheckedChangeListener { _, checked -> prefs.soundEnabled = checked }
        swDoubleSpace.setOnCheckedChangeListener { _, checked -> prefs.doubleSpacePeriod = checked }

        rgTheme.setOnCheckedChangeListener { _, checkedId ->
            prefs.themeMode = when (checkedId) {
                R.id.rbThemeLight -> KeyboardPrefs.THEME_LIGHT
                R.id.rbThemeDark -> KeyboardPrefs.THEME_DARK
                else -> KeyboardPrefs.THEME_AUTO
            }
        }

        rgHeight.setOnCheckedChangeListener { _, checkedId ->
            prefs.keyHeightDp = when (checkedId) {
                R.id.rbHeightCompact -> 38
                R.id.rbHeightTall -> 46
                else -> 42
            }
        }
    }
}
