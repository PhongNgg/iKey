package com.ioskeyboard.vn

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Low-latency, iOS-proportioned keyboard view (Light & Dark themes).
 * Zero dead-zone touch hitboxes: visual gaps live inside LayerDrawable insets so
 * every pixel between keys and rows still triggers the nearest key.
 */
class IOSKeyboardView(
    context: Context,
    private val prefs: KeyboardPrefs,
    private val listener: KeyboardActionListener
) : FrameLayout(context) {

    interface KeyboardActionListener {
        fun onTextKey(text: String)
        fun onBackspace()
        fun onDeleteAll()
        fun onSpace()
        fun onEnter()
        fun onMoveCursor(delta: Int)
        fun onToggleLanguage()
        fun onSwitchImePicker()
        fun onVoiceInput()
        fun onKeyFeedback(type: FeedbackType)
    }

    enum class FeedbackType { CHARACTER, DELETE, SPACE, RETURN }
    enum class Page { LETTERS, NUMBERS, SYMBOLS, EMOJI, NUMPAD }
    enum class ShiftState { OFF, ON, CAPS_LOCK }

    /** Transparent headroom above the keyboard so Row 1 key popups render with zero WindowManager IPC */
    val popupHeadroomPx: Int = dp(58)

    private val insetH = dp(3)
    private val insetTop = dp(5)
    private val insetBottom = dp(6)
    private val numInsetTop = dp(4)
    private val numInsetBottom = dp(4)

    private val keyboardPanel: LinearLayout
    private val popupOverlay: TextView

    private var currentPage: Page = Page.LETTERS
    private var numpadIsPhone: Boolean = false
    private var numpadLeftSymbol: String = "."
    private var shiftState: ShiftState = ShiftState.OFF
    private var lastShiftTapTime: Long = 0L
    private var returnLabel: String = "nhập"
    private var returnIsBlue: Boolean = false
    private var isDark: Boolean = false
    private var currentEmojiCategory: Int = 0

    private val handler = Handler(Looper.getMainLooper())
    private var deleteAllRunnable: Runnable? = null

    private var spaceTrackpadActive = false
    private var spaceLangToggled = false
    private var spaceDownX = 0f
    private var spaceLastX = 0f
    private var spaceLongPressRunnable: Runnable? = null

    private val letterKeyViews = mutableListOf<TextView>()
    private var shiftButtonView: ImageView? = null
    private var spaceTextView: TextView? = null
    private var returnTextView: TextView? = null
    private var micButtonView: ImageView? = null
    private var isVoiceListening: Boolean = false

    private val hidePopupRunnable = Runnable { popupOverlay.visibility = View.GONE }

    init {
        clipChildren = false
        clipToPadding = false
        isMotionEventSplittingEnabled = true

        keyboardPanel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isMotionEventSplittingEnabled = true
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = popupHeadroomPx
            }
        }
        addView(keyboardPanel)

        popupOverlay = TextView(context).apply {
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 29f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            elevation = dp(6).toFloat()
            visibility = View.GONE
            layoutParams = LayoutParams(dp(46), dp(54))
        }
        addView(popupOverlay)

        refreshThemeAndBuild()
    }

    fun refreshThemeAndBuild() {
        isDark = resolveDarkMode()
        keyboardPanel.setBackgroundColor(colorBg())
        keyboardPanel.setPadding(0, dp(3), 0, dp(6))
        stylePopupOverlay()
        rebuildPage()
    }

    fun openNumpadForInputType(inputType: Int) {
        val inputClass = inputType and InputType.TYPE_MASK_CLASS
        val isPhone = inputClass == InputType.TYPE_CLASS_PHONE
        val isSigned = (inputType and InputType.TYPE_NUMBER_FLAG_SIGNED) != 0
        val isDecimal = (inputType and InputType.TYPE_NUMBER_FLAG_DECIMAL) != 0
        numpadIsPhone = isPhone
        numpadLeftSymbol = when {
            isPhone -> "+"
            isSigned && !isDecimal -> "-"
            else -> "."
        }
        currentPage = Page.NUMPAD
        refreshThemeAndBuild()
    }

    fun openLettersPage() {
        currentPage = Page.LETTERS
        refreshThemeAndBuild()
    }

    private fun stylePopupOverlay() {
        popupOverlay.setTextColor(colorText())
        popupOverlay.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(8).toFloat()
            setColor(if (isDark) Color.parseColor("#636366") else Color.WHITE)
            setStroke(dp(1), if (isDark) Color.parseColor("#3A3A3C") else Color.parseColor("#D1D1D6"))
        }
    }

    fun setShiftState(state: ShiftState) {
        if (shiftState == state) return
        shiftState = state
        updateLetterCaseAndShiftIcon()
    }

    fun getShiftState(): ShiftState = shiftState

    fun setReturnAction(label: String, highlightBlue: Boolean) {
        returnLabel = label
        returnIsBlue = highlightBlue
        returnTextView?.let { tv ->
            tv.text = label
            if (currentPage == Page.NUMPAD) {
                tv.setTextColor(if (returnIsBlue) Color.parseColor("#007AFF") else colorText())
            } else {
                tv.background = if (returnIsBlue) {
                    createSelectorDrawable(Color.parseColor("#007AFF"), Color.parseColor("#0062CC"), colorKeyShadow())
                } else {
                    createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
                }
                tv.setTextColor(if (returnIsBlue) Color.WHITE else colorText())
            }
        }
    }

    fun updateSpaceLabel() {
        spaceTextView?.text = when {
            isVoiceListening -> "đang nghe..."
            prefs.telexEnabled -> "dấu cách"
            else -> "space"
        }
    }

    fun setVoiceListening(listening: Boolean) {
        isVoiceListening = listening
        updateSpaceLabel()
        micButtonView?.let { iv ->
            val iconTint = when {
                listening -> Color.parseColor("#FF3B30")
                isDark -> Color.parseColor("#E5E5EA")
                else -> Color.parseColor("#48484A")
            }
            iv.drawable?.mutate()?.setTint(iconTint)
        }
    }

    fun dismissPopup() {
        handler.removeCallbacks(hidePopupRunnable)
        popupOverlay.visibility = View.GONE
    }

    private fun resolveDarkMode(): Boolean {
        return when (prefs.themeMode) {
            KeyboardPrefs.THEME_LIGHT -> false
            KeyboardPrefs.THEME_DARK -> true
            else -> {
                val nightFlags = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                nightFlags == Configuration.UI_MODE_NIGHT_YES
            }
        }
    }

    private fun rebuildPage() {
        dismissPopup()
        keyboardPanel.removeAllViews()
        letterKeyViews.clear()
        shiftButtonView = null
        spaceTextView = null
        returnTextView = null
        micButtonView = null

        when (currentPage) {
            Page.LETTERS -> buildLettersPage()
            Page.NUMBERS -> buildNumbersPage()
            Page.SYMBOLS -> buildSymbolsPage()
            Page.EMOJI -> buildEmojiPage()
            Page.NUMPAD -> buildNumpadPage()
        }
    }

    private fun buildLettersPage() {
        val rowNum = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val row3 = listOf("z", "x", "c", "v", "b", "n", "m")

        if (prefs.numberRowEnabled) {
            keyboardPanel.addView(createNumberRow(rowNum))
        }
        keyboardPanel.addView(createCharRow(row1, sideWeight = 0f, isLetterRow = true))
        keyboardPanel.addView(createCharRow(row2, sideWeight = 0.5f, isLetterRow = true))
        keyboardPanel.addView(createRow3Letters(row3))
        keyboardPanel.addView(createBottomRow(modeLabel = "123", targetModePage = Page.NUMBERS))
        keyboardPanel.addView(createIOSBottomChinBar())
        updateLetterCaseAndShiftIcon()
    }

    private fun buildNumbersPage() {
        val row1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row2 = listOf("-", "/", ":", ";", "(", ")", "₫", "&", "@", "\"")
        val row3 = listOf(".", ",", "?", "!", "'")

        keyboardPanel.addView(createCharRow(row1, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createCharRow(row2, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createRow3Symbols("#+=", Page.SYMBOLS, row3))
        keyboardPanel.addView(createBottomRow(modeLabel = "ABC", targetModePage = Page.LETTERS))
        keyboardPanel.addView(createIOSBottomChinBar())
    }

    private fun buildSymbolsPage() {
        val row1 = listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "=")
        val row2 = listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•")
        val row3 = listOf(".", ",", "?", "!", "'")

        keyboardPanel.addView(createCharRow(row1, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createCharRow(row2, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createRow3Symbols("123", Page.NUMBERS, row3))
        keyboardPanel.addView(createBottomRow(modeLabel = "ABC", targetModePage = Page.LETTERS))
        keyboardPanel.addView(createIOSBottomChinBar())
    }

    private fun createNumberRow(keys: List<String>): LinearLayout {
        val numHeight = (prefs.keyHeightDp * 0.80f).toInt().coerceAtLeast(30)
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isMotionEventSplittingEnabled = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(numHeight) + numInsetTop + numInsetBottom
            )
        }
        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = false, vTop = numInsetTop, vBot = numInsetBottom)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            row.addView(tv)
        }
        return row
    }

    private fun createRowContainer(): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isMotionEventSplittingEnabled = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(prefs.keyHeightDp) + insetTop + insetBottom
            )
        }
    }

    private fun createCharRow(keys: List<String>, sideWeight: Float, isLetterRow: Boolean): LinearLayout {
        val row = createRowContainer()
        val keyViews = keys.map { k ->
            val tv = createCharKeyView(k, weight = 1f, isLetter = isLetterRow)
            if (isLetterRow) letterKeyViews.add(tv)
            tv
        }
        if (sideWeight > 0f && keyViews.isNotEmpty()) {
            row.addView(createForwardingSpacer(sideWeight, keyViews.first()))
        }
        for (tv in keyViews) {
            row.addView(tv)
        }
        if (sideWeight > 0f && keyViews.isNotEmpty()) {
            row.addView(createForwardingSpacer(sideWeight, keyViews.last()))
        }
        return row
    }

    private fun createRow3Letters(keys: List<String>): LinearLayout {
        val row = createRowContainer()
        val shiftBtn = createShiftKeyView(weight = 1.32f)
        shiftButtonView = shiftBtn
        val backBtn = createBackspaceKeyView(weight = 1.32f)

        row.addView(shiftBtn)
        row.addView(createForwardingSpacer(0.18f, shiftBtn))

        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = true)
            letterKeyViews.add(tv)
            row.addView(tv)
        }

        row.addView(createForwardingSpacer(0.18f, backBtn))
        row.addView(backBtn)
        return row
    }

    private fun createRow3Symbols(switchLabel: String, targetPage: Page, keys: List<String>): LinearLayout {
        val row = createRowContainer()
        val switchBtn = createSpecialTextKey(switchLabel, weight = 1.32f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = targetPage
            rebuildPage()
        }
        val backBtn = createBackspaceKeyView(weight = 1.32f)

        row.addView(switchBtn)
        row.addView(createForwardingSpacer(0.18f, switchBtn))

        for (k in keys) {
            row.addView(createCharKeyView(k, weight = 1.4f, isLetter = false))
        }

        row.addView(createForwardingSpacer(0.18f, backBtn))
        row.addView(backBtn)
        return row
    }

    private fun createBottomRow(modeLabel: String, targetModePage: Page): LinearLayout {
        val row = createRowContainer()

        val modeBtn = createSpecialTextKey(modeLabel, weight = 1.35f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = targetModePage
            rebuildPage()
        }
        if (modeLabel == "123") {
            modeBtn.setOnLongClickListener {
                performHaptic()
                numpadIsPhone = false
                numpadLeftSymbol = "."
                currentPage = Page.NUMPAD
                rebuildPage()
                true
            }
        }
        row.addView(modeBtn)

        val commaKey = createCharKeyView(",", weight = 0.95f, isLetter = false)
        commaKey.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
        row.addView(commaKey)

        val spaceKey = createSpaceKeyView(weight = 4.55f)
        spaceTextView = spaceKey
        row.addView(spaceKey)

        val periodKey = createCharKeyView(".", weight = 0.95f, isLetter = false)
        periodKey.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
        row.addView(periodKey)

        val returnKey = createReturnKeyView(weight = 2.20f)
        returnTextView = returnKey
        row.addView(returnKey)

        return row
    }

    /** iPhone-style bottom chin bar with Globe (left) and Voice/Gemini Mic (right) */
    private fun createIOSBottomChinBar(): LinearLayout {
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(40)
            )
            setPadding(dp(16), 0, dp(16), 0)
        }

        val iconTint = if (isDark) Color.parseColor("#E5E5EA") else Color.parseColor("#48484A")

        val emojiBtn = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createChinButtonSelector()
            val d = ContextCompat.getDrawable(context, R.drawable.ic_emoji)?.mutate()
            d?.setTint(iconTint)
            setImageDrawable(d)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(40))
            setOnClickListener {
                performHaptic()
                listener.onKeyFeedback(FeedbackType.CHARACTER)
                currentPage = if (currentPage == Page.EMOJI) Page.LETTERS else Page.EMOJI
                rebuildPage()
            }
            setOnLongClickListener {
                performHaptic()
                listener.onSwitchImePicker()
                true
            }
        }

        val spacer = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }

        val micBtn = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createChinButtonSelector()
            val d = ContextCompat.getDrawable(context, R.drawable.ic_mic)?.mutate()
            d?.setTint(iconTint)
            setImageDrawable(d)
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(40))
            setOnClickListener {
                performHaptic()
                listener.onKeyFeedback(FeedbackType.CHARACTER)
                listener.onVoiceInput()
            }
        }

        micButtonView = micBtn
        if (isVoiceListening) {
            micBtn.drawable?.mutate()?.setTint(Color.parseColor("#FF3B30"))
        }
        bar.addView(emojiBtn)
        bar.addView(spacer)
        bar.addView(micBtn)
        return bar
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createCharKeyView(
        baseChar: String,
        weight: Float,
        isLetter: Boolean,
        vTop: Int = insetTop,
        vBot: Int = insetBottom
    ): TextView {
        val tv = TextView(context).apply {
            text = baseChar
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (isLetter) 21.5f else 20f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createSelectorDrawable(colorCharKey(), colorCharKeyPressed(), colorKeyShadow(), vTop, vBot)
            setPadding(insetH, vTop, insetH, vBot)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        }

        tv.setOnTouchListener { view, event ->
            val currentLabel = (view as TextView).text.toString()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    if (prefs.popupEnabled) showKeyPopup(view, currentLabel)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    scheduleHidePopup()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(currentLabel)
                    if (isLetter && shiftState == ShiftState.ON) {
                        shiftState = ShiftState.OFF
                        updateLetterCaseAndShiftIcon()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    dismissPopup()
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createShiftKeyView(weight: Float): ImageView {
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            setPadding(insetH, insetTop, insetH, insetBottom)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        }
        iv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    val now = System.currentTimeMillis()
                    shiftState = when (shiftState) {
                        ShiftState.OFF -> {
                            lastShiftTapTime = now
                            ShiftState.ON
                        }
                        ShiftState.ON -> {
                            if (now - lastShiftTapTime < 350L) ShiftState.CAPS_LOCK else ShiftState.OFF
                        }
                        ShiftState.CAPS_LOCK -> ShiftState.OFF
                    }
                    updateLetterCaseAndShiftIcon()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return iv
    }

    private fun updateLetterCaseAndShiftIcon() {
        val upper = shiftState != ShiftState.OFF
        for (tv in letterKeyViews) {
            val raw = tv.text.toString()
            val target = if (upper) raw.uppercase() else raw.lowercase()
            if (raw != target) {
                tv.text = target
            }
        }
        shiftButtonView?.let { iv ->
            val iconRes = when (shiftState) {
                ShiftState.OFF -> R.drawable.ic_shift_off
                ShiftState.ON -> R.drawable.ic_shift_on
                ShiftState.CAPS_LOCK -> R.drawable.ic_caps_lock
            }
            val drawable = ContextCompat.getDrawable(context, iconRes)?.mutate()
            if (shiftState == ShiftState.OFF) {
                iv.background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
                drawable?.setTint(colorText())
            } else {
                val activeBg = if (isDark) Color.parseColor("#EBEBF0") else Color.WHITE
                iv.background = createSelectorDrawable(activeBg, colorCharKeyPressed(), colorKeyShadow())
                drawable?.setTint(Color.BLACK)
            }
            iv.setImageDrawable(drawable)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBackspaceKeyView(weight: Float): ImageView {
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            setPadding(insetH, insetTop, insetH, insetBottom)
            val d = ContextCompat.getDrawable(context, R.drawable.ic_backspace)?.mutate()
            d?.setTint(colorText())
            setImageDrawable(d)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        }

        iv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.DELETE)
                    listener.onBackspace()
                    scheduleDeleteAll()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    cancelDeleteAll()
                    true
                }
                else -> false
            }
        }
        return iv
    }

    private fun scheduleDeleteAll() {
        cancelDeleteAll()
        val runnable = Runnable {
            if (prefs.hapticEnabled) {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            }
            listener.onKeyFeedback(FeedbackType.DELETE)
            listener.onDeleteAll()
        }
        deleteAllRunnable = runnable
        handler.postDelayed(runnable, 550L)
    }

    private fun cancelDeleteAll() {
        deleteAllRunnable?.let { handler.removeCallbacks(it) }
        deleteAllRunnable = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createSpaceKeyView(weight: Float): TextView {
        val tv = TextView(context).apply {
            text = if (prefs.telexEnabled) "dấu cách" else "space"
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createSelectorDrawable(colorCharKey(), colorCharKeyPressed(), colorKeyShadow())
            setPadding(insetH, insetTop, insetH, insetBottom)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        }

        val stepPx = dp(12).toFloat()
        val dragSlopPx = dp(16).toFloat()
        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    spaceTrackpadActive = false
                    spaceLangToggled = false
                    spaceDownX = event.x
                    spaceLastX = event.x
                    val lp = Runnable {
                        if (!spaceTrackpadActive) {
                            spaceLangToggled = true
                            if (prefs.hapticEnabled) {
                                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                            }
                            listener.onKeyFeedback(FeedbackType.CHARACTER)
                            listener.onToggleLanguage()
                            updateSpaceLabel()
                        }
                    }
                    spaceLongPressRunnable = lp
                    handler.postDelayed(lp, 420L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!spaceLangToggled) {
                        if (!spaceTrackpadActive && abs(event.x - spaceDownX) >= dragSlopPx) {
                            spaceTrackpadActive = true
                            spaceLongPressRunnable?.let { handler.removeCallbacks(it) }
                            spaceLongPressRunnable = null
                            spaceLastX = event.x
                        }
                        if (spaceTrackpadActive) {
                            val dx = event.x - spaceLastX
                            if (abs(dx) >= stepPx) {
                                val steps = (dx / stepPx).toInt()
                                spaceLastX += steps * stepPx
                                listener.onMoveCursor(steps)
                                performHaptic()
                            }
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    spaceLongPressRunnable?.let { handler.removeCallbacks(it) }
                    spaceLongPressRunnable = null
                    if (!spaceTrackpadActive && !spaceLangToggled && event.actionMasked == MotionEvent.ACTION_UP) {
                        performHaptic()
                        listener.onKeyFeedback(FeedbackType.SPACE)
                        listener.onSpace()
                    }
                    spaceTrackpadActive = false
                    spaceLangToggled = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createReturnKeyView(weight: Float): TextView {
        val tv = TextView(context).apply {
            text = returnLabel
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = if (returnIsBlue) {
                createSelectorDrawable(Color.parseColor("#007AFF"), Color.parseColor("#0062CC"), colorKeyShadow())
            } else {
                createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            }
            setTextColor(if (returnIsBlue) Color.WHITE else colorText())
            setPadding(insetH, insetTop, insetH, insetBottom)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        }

        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.RETURN)
                    listener.onEnter()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createSpecialTextKey(label: String, weight: Float, onClick: () -> Unit): TextView {
        val tv = TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            setPadding(insetH, insetTop, insetH, insetBottom)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        }
        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    performHaptic()
                    onClick()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    private fun createSpecialIconKey(
        iconRes: Int,
        weight: Float,
        onClick: () -> Unit,
        onLongClick: (() -> Unit)? = null
    ): ImageView {
        return ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            setPadding(insetH, insetTop, insetH, insetBottom)
            val d = ContextCompat.getDrawable(context, iconRes)?.mutate()
            d?.setTint(colorText())
            setImageDrawable(d)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
            setOnClickListener {
                performHaptic()
                onClick()
            }
            if (onLongClick != null) {
                setOnLongClickListener {
                    onLongClick()
                    true
                }
            }
        }
    }

    private fun buildEmojiPage() {
        val numRowExtra = if (prefs.numberRowEnabled) dp((prefs.keyHeightDp * 0.80f).toInt().coerceAtLeast(30)) + numInsetTop + numInsetBottom else 0
        val rowFullH = dp(prefs.keyHeightDp) + insetTop + insetBottom
        val totalKeyboardHeight = rowFullH * 4 + numRowExtra
        val gridAreaHeight = (totalKeyboardHeight - rowFullH - dp(4)).coerceAtLeast(dp(140))

        val scrollView = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                gridAreaHeight
            ).apply {
                bottomMargin = dp(4)
            }
            isVerticalScrollBarEnabled = false
        }

        val grid = GridLayout(context).apply {
            columnCount = 8
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val emojis = EmojiData.categories[currentEmojiCategory].emojis
        for (emoji in emojis) {
            val cell = TextView(context).apply {
                text = emoji
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                }
                setOnClickListener {
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(emoji)
                }
            }
            grid.addView(cell)
        }
        scrollView.addView(grid)
        keyboardPanel.addView(scrollView)

        val bottomBar = createRowContainer()
        bottomBar.addView(createSpecialTextKey("ABC", weight = 1.5f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = Page.LETTERS
            rebuildPage()
        })

        EmojiData.categories.forEachIndexed { idx, category ->
            val selected = idx == currentEmojiCategory
            val tab = TextView(context).apply {
                text = category.icon
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                alpha = if (selected) 1f else 0.55f
                setPadding(dp(2), insetTop, dp(2), insetBottom)
                if (selected) {
                    background = createKeyDrawable(colorCharKey(), colorKeyShadow(), insetTop, insetBottom)
                }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener {
                    currentEmojiCategory = idx
                    rebuildPage()
                }
            }
            bottomBar.addView(tab)
        }

        bottomBar.addView(createBackspaceKeyView(weight = 1.5f))
        keyboardPanel.addView(bottomBar)
        keyboardPanel.addView(createIOSBottomChinBar())
    }

    /** iPhone-style 4x3 numeric keypad (1-9, 0, symbol, delete) */
    private fun buildNumpadPage() {
        val rows = listOf(
            listOf("1" to "", "2" to "ABC", "3" to "DEF"),
            listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
            listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ")
        )
        val padKeyHeight = dp(52) + numInsetTop + numInsetBottom

        for (r in rows) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isMotionEventSplittingEnabled = true
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    padKeyHeight
                )
            }
            for ((digit, letters) in r) {
                row.addView(createNumpadDigitKey(digit, letters))
            }
            keyboardPanel.addView(row)
        }

        // Row 4: [ . / + / - ]  [ 0 ]  [ Backspace ]
        val row4 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isMotionEventSplittingEnabled = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                padKeyHeight
            )
        }
        row4.addView(createNumpadSymbolKey(numpadLeftSymbol))
        row4.addView(createNumpadDigitKey("0", if (numpadIsPhone) "+" else ""))
        row4.addView(createNumpadBackspaceKey())
        keyboardPanel.addView(row4)

        // Bottom chin bar with ABC (left) and Return/Xong (right)
        keyboardPanel.addView(createNumpadChinBar())
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createNumpadDigitKey(digit: String, subLabel: String): View {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = createSelectorDrawable(colorCharKey(), colorCharKeyPressed(), colorKeyShadow(), numInsetTop, numInsetBottom)
            setPadding(insetH, numInsetTop, insetH, numInsetBottom)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }

        val tvDigit = TextView(context).apply {
            text = digit
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        container.addView(tvDigit)

        if (subLabel.isNotEmpty()) {
            val tvSub = TextView(context).apply {
                text = subLabel
                gravity = Gravity.CENTER
                includeFontPadding = false
                setTextColor(colorText())
                alpha = 0.62f
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
                letterSpacing = 0.08f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            container.addView(tvSub)
        }

        container.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(digit)
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return container
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createNumpadSymbolKey(symbol: String): TextView {
        val tv = TextView(context).apply {
            text = symbol
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createSelectorDrawable(Color.TRANSPARENT, colorSpecialKeyPressed(), Color.TRANSPARENT, numInsetTop, numInsetBottom)
            setPadding(insetH, numInsetTop, insetH, numInsetBottom)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(symbol)
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createNumpadBackspaceKey(): ImageView {
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createSelectorDrawable(Color.TRANSPARENT, colorSpecialKeyPressed(), Color.TRANSPARENT, numInsetTop, numInsetBottom)
            setPadding(insetH, numInsetTop, insetH, numInsetBottom)
            val d = ContextCompat.getDrawable(context, R.drawable.ic_backspace)?.mutate()
            d?.setTint(colorText())
            setImageDrawable(d)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }
        iv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.DELETE)
                    listener.onBackspace()
                    scheduleDeleteAll()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    cancelDeleteAll()
                    true
                }
                else -> false
            }
        }
        return iv
    }

    private fun createNumpadChinBar(): LinearLayout {
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(40)
            )
            setPadding(dp(12), 0, dp(12), 0)
        }

        val abcBtn = TextView(context).apply {
            text = "ABC"
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = createChinButtonSelector()
            setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(36)
            )
            setOnClickListener {
                performHaptic()
                listener.onKeyFeedback(FeedbackType.CHARACTER)
                currentPage = Page.LETTERS
                rebuildPage()
            }
        }

        val spacer = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }

        val doneBtn = TextView(context).apply {
            text = returnLabel
            gravity = Gravity.CENTER
            setTextColor(if (returnIsBlue) Color.parseColor("#007AFF") else colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = createChinButtonSelector()
            setPadding(dp(14), 0, dp(14), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(36)
            )
            setOnClickListener {
                performHaptic()
                listener.onKeyFeedback(FeedbackType.RETURN)
                listener.onEnter()
            }
        }
        returnTextView = doneBtn

        bar.addView(abcBtn)
        bar.addView(spacer)
        bar.addView(doneBtn)
        return bar
    }

    /** Instant in-layout key popup positioned above the visible keycap */
    private fun showKeyPopup(anchor: View, label: String) {
        handler.removeCallbacks(hidePopupRunnable)
        val row = anchor.parent as? View ?: return
        val x = keyboardPanel.left + row.left + anchor.left + (anchor.width - popupOverlay.layoutParams.width) / 2f
        val y = keyboardPanel.top + row.top + anchor.top + anchor.paddingTop - popupOverlay.layoutParams.height - dp(4).toFloat()
        val maxX = (width - popupOverlay.layoutParams.width - dp(2)).toFloat().coerceAtLeast(0f)

        popupOverlay.text = label
        popupOverlay.translationX = x.coerceIn(dp(2).toFloat(), maxX)
        popupOverlay.translationY = y.coerceAtLeast(dp(2).toFloat())
        popupOverlay.visibility = View.VISIBLE
        popupOverlay.bringToFront()
    }

    private fun scheduleHidePopup() {
        handler.removeCallbacks(hidePopupRunnable)
        handler.postDelayed(hidePopupRunnable, 45L)
    }

    /** Forwards touches on side spacers (e.g. left of A, right of L) to the adjacent key */
    @SuppressLint("ClickableViewAccessibility")
    private fun createForwardingSpacer(weight: Float, target: View): View {
        return View(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
            setOnTouchListener { _, event -> target.dispatchTouchEvent(event) }
        }
    }

    private fun createChinButtonSelector(): Drawable {
        val pressedBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(10).toFloat()
            setColor(if (isDark) Color.parseColor("#38FFFFFF") else Color.parseColor("#24000000"))
        }
        val normalBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.TRANSPARENT)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressedBg)
            addState(intArrayOf(), normalBg)
        }
    }

    private fun createSelectorDrawable(
        normalColor: Int,
        pressedColor: Int,
        shadowColor: Int,
        vTop: Int = insetTop,
        vBot: Int = insetBottom
    ): Drawable {
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), createKeyDrawable(pressedColor, shadowColor, vTop, vBot))
            addState(intArrayOf(), createKeyDrawable(normalColor, shadowColor, vTop, vBot))
        }
    }

    private fun createKeyDrawable(
        fillColor: Int,
        shadowColor: Int,
        vTop: Int = insetTop,
        vBot: Int = insetBottom
    ): Drawable {
        val radius = dp(5).toFloat()
        val shadow = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(shadowColor)
        }
        val face = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(fillColor)
        }
        return LayerDrawable(arrayOf(shadow, face)).apply {
            setLayerInset(0, insetH, vTop, insetH, vBot)
            setLayerInset(1, insetH, vTop, insetH, vBot + dp(1))
        }
    }

    private fun performHaptic() {
        if (prefs.hapticEnabled) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun colorBg(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_bg else R.color.ios_light_bg)
    private fun colorCharKey(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key else R.color.ios_light_key)
    private fun colorCharKeyPressed(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key_pressed else R.color.ios_light_key_pressed)
    private fun colorSpecialKey(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_special_key else R.color.ios_light_special_key)
    private fun colorSpecialKeyPressed(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_special_pressed else R.color.ios_light_special_pressed)
    private fun colorKeyShadow(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key_shadow else R.color.ios_light_key_shadow)
    private fun colorText(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_text else R.color.ios_light_text)
}
