package com.ioskeyboard.vn

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Programmatic iOS-proportioned keyboard view (Light & Dark themes).
 * Zero suggestion bar, zero swipe trail — pure iPhone layout fidelity.
 */
class IOSKeyboardView(
    context: Context,
    private val prefs: KeyboardPrefs,
    private val listener: KeyboardActionListener
) : LinearLayout(context) {

    interface KeyboardActionListener {
        fun onTextKey(text: String)
        fun onBackspace()
        fun onSpace()
        fun onEnter()
        fun onMoveCursor(delta: Int)
        fun onToggleLanguage()
        fun onSwitchImePicker()
        fun onKeyFeedback(type: FeedbackType)
    }

    enum class FeedbackType { CHARACTER, DELETE, SPACE, RETURN }
    enum class Page { LETTERS, NUMBERS, SYMBOLS, EMOJI }
    enum class ShiftState { OFF, ON, CAPS_LOCK }

    private var currentPage: Page = Page.LETTERS
    private var shiftState: ShiftState = ShiftState.OFF
    private var lastShiftTapTime: Long = 0L
    private var returnLabel: String = "nhập"
    private var returnIsBlue: Boolean = false
    private var isDark: Boolean = false
    private var currentEmojiCategory: Int = 0

    private val handler = Handler(Looper.getMainLooper())
    private var repeatDeleteRunnable: Runnable? = null

    // Spacebar trackpad cursor drag state
    private var spaceTrackpadActive = false
    private var spaceLastX = 0f
    private var spaceLongPressRunnable: Runnable? = null

    // Floating iOS key popup preview
    private var popupWindow: PopupWindow? = null
    private var popupTextView: TextView? = null

    // Track letter TextViews for fast Shift case toggle without rebuilding view tree
    private val letterKeyViews = mutableListOf<TextView>()
    private var shiftButtonView: ImageView? = null
    private var spaceTextView: TextView? = null
    private var returnTextView: TextView? = null

    init {
        orientation = VERTICAL
        isClickable = true
        refreshThemeAndBuild()
    }

    fun refreshThemeAndBuild() {
        isDark = resolveDarkMode()
        setBackgroundColor(colorBg())
        val padH = dp(3)
        val padTop = dp(8)
        val padBottom = dp(6)
        setPadding(padH, padTop, padH, padBottom)
        rebuildPage()
    }

    fun setShiftState(state: ShiftState) {
        shiftState = state
        updateLetterCaseAndShiftIcon()
    }

    fun getShiftState(): ShiftState = shiftState

    fun setReturnAction(label: String, highlightBlue: Boolean) {
        returnLabel = label
        returnIsBlue = highlightBlue
        returnTextView?.let { tv ->
            tv.text = label
            styleReturnKey(tv, pressed = false)
        }
    }

    fun updateSpaceLabel() {
        spaceTextView?.text = if (prefs.telexEnabled) "dấu cách" else "space"
    }

    fun dismissPopup() {
        popupWindow?.dismiss()
    }

    private fun resolveDarkMode(): Boolean {
        return when (prefs.themeMode) {
            KeyboardPrefs.THEME_LIGHT -> false
            KeyboardPrefs.THEME_DARK -> true
            else -> {
                val nightFlags = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                nightFlags == Configuration.UI_MODE_NIGHT_YES
            }
        }
    }

    private fun rebuildPage() {
        dismissPopup()
        removeAllViews()
        letterKeyViews.clear()
        shiftButtonView = null
        spaceTextView = null
        returnTextView = null

        when (currentPage) {
            Page.LETTERS -> buildLettersPage()
            Page.NUMBERS -> buildNumbersPage()
            Page.SYMBOLS -> buildSymbolsPage()
            Page.EMOJI -> buildEmojiPage()
        }
    }

    private fun buildLettersPage() {
        val rowNum = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val row3 = listOf("z", "x", "c", "v", "b", "n", "m")

        if (prefs.numberRowEnabled) {
            addView(createNumberRow(rowNum))
        }
        addView(createCharRow(row1, sideWeight = 0f, isLetterRow = true))
        addView(createCharRow(row2, sideWeight = 0.5f, isLetterRow = true))
        addView(createRow3Letters(row3))
        addView(createBottomRow(modeLabel = "123", targetModePage = Page.NUMBERS))
        updateLetterCaseAndShiftIcon()
    }

    private fun buildNumbersPage() {
        val row1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row2 = listOf("-", "/", ":", ";", "(", ")", "₫", "&", "@", "\"")
        val row3 = listOf(".", ",", "?", "!", "'")

        addView(createCharRow(row1, sideWeight = 0f, isLetterRow = false))
        addView(createCharRow(row2, sideWeight = 0f, isLetterRow = false))
        addView(createRow3Symbols("#+=", Page.SYMBOLS, row3))
        addView(createBottomRow(modeLabel = "ABC", targetModePage = Page.LETTERS))
    }

    private fun buildSymbolsPage() {
        val row1 = listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "=")
        val row2 = listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•")
        val row3 = listOf(".", ",", "?", "!", "'")

        addView(createCharRow(row1, sideWeight = 0f, isLetterRow = false))
        addView(createCharRow(row2, sideWeight = 0f, isLetterRow = false))
        addView(createRow3Symbols("123", Page.NUMBERS, row3))
        addView(createBottomRow(modeLabel = "ABC", targetModePage = Page.LETTERS))
    }

    private fun createNumberRow(keys: List<String>): LinearLayout {
        val numHeight = (prefs.keyHeightDp * 0.80f).toInt().coerceAtLeast(30)
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(numHeight)).apply {
                bottomMargin = dp(8)
            }
        }
        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = false)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            row.addView(tv)
        }
        return row
    }

    private fun createRowContainer(bottomMarginDp: Int = 11): LinearLayout {
        return LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, dp(prefs.keyHeightDp)).apply {
                bottomMargin = dp(bottomMarginDp)
            }
        }
    }

    private fun createCharRow(keys: List<String>, sideWeight: Float, isLetterRow: Boolean): LinearLayout {
        val row = createRowContainer()
        if (sideWeight > 0f) {
            row.addView(createSpacer(sideWeight))
        }
        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = isLetterRow)
            if (isLetterRow) letterKeyViews.add(tv)
            row.addView(tv)
        }
        if (sideWeight > 0f) {
            row.addView(createSpacer(sideWeight))
        }
        return row
    }

    private fun createRow3Letters(keys: List<String>): LinearLayout {
        val row = createRowContainer()
        val shiftBtn = createShiftKeyView(weight = 1.32f)
        shiftButtonView = shiftBtn
        row.addView(shiftBtn)
        row.addView(createSpacer(0.18f))

        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = true)
            letterKeyViews.add(tv)
            row.addView(tv)
        }

        row.addView(createSpacer(0.18f))
        row.addView(createBackspaceKeyView(weight = 1.32f))
        return row
    }

    private fun createRow3Symbols(switchLabel: String, targetPage: Page, keys: List<String>): LinearLayout {
        val row = createRowContainer()
        row.addView(createSpecialTextKey(switchLabel, weight = 1.32f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = targetPage
            rebuildPage()
        })
        row.addView(createSpacer(0.18f))

        for (k in keys) {
            row.addView(createCharKeyView(k, weight = 1.4f, isLetter = false))
        }

        row.addView(createSpacer(0.18f))
        row.addView(createBackspaceKeyView(weight = 1.32f))
        return row
    }

    private fun createBottomRow(modeLabel: String, targetModePage: Page): LinearLayout {
        val row = createRowContainer(bottomMarginDp = 2)

        // 123 / ABC
        row.addView(createSpecialTextKey(modeLabel, weight = 1.35f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = targetModePage
            rebuildPage()
        })

        // Emoji button
        row.addView(createSpecialIconKey(R.drawable.ic_emoji, weight = 1.0f,
            onClick = {
                listener.onKeyFeedback(FeedbackType.CHARACTER)
                currentPage = Page.EMOJI
                rebuildPage()
            }
        ))

        // Globe button (tap = toggle VI Telex / EN, long-press = system IME picker)
        row.addView(createSpecialIconKey(R.drawable.ic_globe, weight = 1.0f,
            onClick = {
                listener.onKeyFeedback(FeedbackType.CHARACTER)
                listener.onToggleLanguage()
                updateSpaceLabel()
            },
            onLongClick = {
                performHaptic()
                listener.onSwitchImePicker()
            }
        ))

        // Spacebar (tap = space, long-press + drag = iPhone cursor trackpad)
        val spaceKey = createSpaceKeyView(weight = 4.4f)
        spaceTextView = spaceKey
        row.addView(spaceKey)

        // Return / Action key
        val returnKey = createReturnKeyView(weight = 2.25f)
        returnTextView = returnKey
        row.addView(returnKey)

        return row
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createCharKeyView(baseChar: String, weight: Float, isLetter: Boolean): TextView {
        val tv = TextView(context).apply {
            text = baseChar
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (isLetter) 22f else 20f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createKeyDrawable(colorCharKey(), colorKeyShadow())
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

        tv.setOnTouchListener { view, event ->
            val currentLabel = (view as TextView).text.toString()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.background = createKeyDrawable(colorCharKeyPressed(), colorKeyShadow())
                    if (prefs.popupEnabled) showKeyPopup(view, currentLabel)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.background = createKeyDrawable(colorCharKey(), colorKeyShadow())
                    dismissPopup()
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(currentLabel)
                    if (isLetter && shiftState == ShiftState.ON) {
                        shiftState = ShiftState.OFF
                        updateLetterCaseAndShiftIcon()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.background = createKeyDrawable(colorCharKey(), colorKeyShadow())
                    dismissPopup()
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createShiftKeyView(weight: Float): ImageView {
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }
        iv.setOnClickListener {
            performHaptic()
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            val now = System.currentTimeMillis()
            shiftState = when (shiftState) {
                ShiftState.OFF -> {
                    lastShiftTapTime = now
                    ShiftState.ON
                }
                ShiftState.ON -> {
                    if (now - lastShiftTapTime < 350L) ShiftState.CAPS_LOCK else ShiftState.OFF
                }
                ShiftState.CAPS_LOCK -> ShiftState.OFF
            }
            updateLetterCaseAndShiftIcon()
        }
        return iv
    }

    private fun updateLetterCaseAndShiftIcon() {
        val upper = shiftState != ShiftState.OFF
        for (tv in letterKeyViews) {
            val raw = tv.text.toString()
            tv.text = if (upper) raw.uppercase() else raw.lowercase()
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (upper) 20.5f else 22.5f)
        }
        shiftButtonView?.let { iv ->
            val iconRes = when (shiftState) {
                ShiftState.OFF -> R.drawable.ic_shift_off
                ShiftState.ON -> R.drawable.ic_shift_on
                ShiftState.CAPS_LOCK -> R.drawable.ic_caps_lock
            }
            val drawable = ContextCompat.getDrawable(context, iconRes)?.mutate()
            if (shiftState == ShiftState.OFF) {
                iv.background = createKeyDrawable(colorSpecialKey(), colorKeyShadow())
                drawable?.setTint(colorText())
            } else {
                // Active Shift on iPhone turns bright white with dark arrow
                val activeBg = if (isDark) Color.parseColor("#EBEBF0") else Color.WHITE
                iv.background = createKeyDrawable(activeBg, colorKeyShadow())
                drawable?.setTint(Color.BLACK)
            }
            iv.setImageDrawable(drawable)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBackspaceKeyView(weight: Float): ImageView {
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createKeyDrawable(colorSpecialKey(), colorKeyShadow())
            val d = ContextCompat.getDrawable(context, R.drawable.ic_backspace)?.mutate()
            d?.setTint(colorText())
            setImageDrawable(d)
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

        iv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.background = createKeyDrawable(colorSpecialKeyPressed(), colorKeyShadow())
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.DELETE)
                    listener.onBackspace()
                    startRepeatDelete()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.background = createKeyDrawable(colorSpecialKey(), colorKeyShadow())
                    stopRepeatDelete()
                    true
                }
                else -> false
            }
        }
        return iv
    }

    private fun startRepeatDelete() {
        stopRepeatDelete()
        val runnable = object : Runnable {
            override fun run() {
                listener.onBackspace()
                handler.postDelayed(this, 65L)
            }
        }
        repeatDeleteRunnable = runnable
        handler.postDelayed(runnable, 380L)
    }

    private fun stopRepeatDelete() {
        repeatDeleteRunnable?.let { handler.removeCallbacks(it) }
        repeatDeleteRunnable = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createSpaceKeyView(weight: Float): TextView {
        val tv = TextView(context).apply {
            text = if (prefs.telexEnabled) "dấu cách" else "space"
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createKeyDrawable(colorCharKey(), colorKeyShadow())
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

        val stepPx = dp(12).toFloat()
        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.background = createKeyDrawable(colorCharKeyPressed(), colorKeyShadow())
                    spaceTrackpadActive = false
                    spaceLastX = event.x
                    val lp = Runnable {
                        spaceTrackpadActive = true
                        performHaptic()
                    }
                    spaceLongPressRunnable = lp
                    handler.postDelayed(lp, 280L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (spaceTrackpadActive) {
                        val dx = event.x - spaceLastX
                        if (abs(dx) >= stepPx) {
                            val steps = (dx / stepPx).toInt()
                            spaceLastX += steps * stepPx
                            listener.onMoveCursor(steps)
                            performHaptic()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.background = createKeyDrawable(colorCharKey(), colorKeyShadow())
                    spaceLongPressRunnable?.let { handler.removeCallbacks(it) }
                    spaceLongPressRunnable = null
                    if (!spaceTrackpadActive && event.actionMasked == MotionEvent.ACTION_UP) {
                        performHaptic()
                        listener.onKeyFeedback(FeedbackType.SPACE)
                        listener.onSpace()
                    }
                    spaceTrackpadActive = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createReturnKeyView(weight: Float): TextView {
        val tv = TextView(context).apply {
            text = returnLabel
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }
        styleReturnKey(tv, pressed = false)

        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    styleReturnKey(tv, pressed = true)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    styleReturnKey(tv, pressed = false)
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.RETURN)
                    listener.onEnter()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    styleReturnKey(tv, pressed = false)
                    true
                }
                else -> false
            }
        }
        return tv
    }

    private fun styleReturnKey(tv: TextView, pressed: Boolean) {
        if (returnIsBlue) {
            val bg = if (pressed) Color.parseColor("#0062CC") else Color.parseColor("#007AFF")
            tv.background = createKeyDrawable(bg, colorKeyShadow())
            tv.setTextColor(Color.WHITE)
        } else {
            val bg = if (pressed) colorSpecialKeyPressed() else colorSpecialKey()
            tv.background = createKeyDrawable(bg, colorKeyShadow())
            tv.setTextColor(colorText())
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createSpecialTextKey(label: String, weight: Float, onClick: () -> Unit): TextView {
        val tv = TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createKeyDrawable(colorSpecialKey(), colorKeyShadow())
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }
        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.background = createKeyDrawable(colorSpecialKeyPressed(), colorKeyShadow())
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.background = createKeyDrawable(colorSpecialKey(), colorKeyShadow())
                    performHaptic()
                    onClick()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.background = createKeyDrawable(colorSpecialKey(), colorKeyShadow())
                    true
                }
                else -> false
            }
        }
        return tv
    }

    private fun createSpecialIconKey(
        iconRes: Int,
        weight: Float,
        onClick: () -> Unit,
        onLongClick: (() -> Unit)? = null
    ): ImageView {
        return ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createKeyDrawable(colorSpecialKey(), colorKeyShadow())
            val d = ContextCompat.getDrawable(context, iconRes)?.mutate()
            d?.setTint(colorText())
            setImageDrawable(d)
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
            setOnClickListener {
                performHaptic()
                onClick()
            }
            if (onLongClick != null) {
                setOnLongClickListener {
                    onLongClick()
                    true
                }
            }
        }
    }

    private fun buildEmojiPage() {
        val numRowExtra = if (prefs.numberRowEnabled) dp((prefs.keyHeightDp * 0.80f).toInt().coerceAtLeast(30)) + dp(8) else 0
        val totalKeyboardHeight = dp(prefs.keyHeightDp) * 4 + dp(11) * 3 + dp(2) + numRowExtra
        val barHeight = dp(prefs.keyHeightDp)
        val gridAreaHeight = (totalKeyboardHeight - barHeight - dp(8)).coerceAtLeast(dp(140))

        val scrollView = ScrollView(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, gridAreaHeight).apply {
                bottomMargin = dp(8)
            }
            isVerticalScrollBarEnabled = false
        }

        val grid = GridLayout(context).apply {
            columnCount = 8
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val emojis = EmojiData.categories[currentEmojiCategory].emojis
        for (emoji in emojis) {
            val cell = TextView(context).apply {
                text = emoji
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                }
                setOnClickListener {
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(emoji)
                }
            }
            grid.addView(cell)
        }
        scrollView.addView(grid)
        addView(scrollView)

        // Emoji bottom navigation bar (ABC + categories + Backspace)
        val bottomBar = createRowContainer(bottomMarginDp = 2)
        bottomBar.addView(createSpecialTextKey("ABC", weight = 1.5f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = Page.LETTERS
            rebuildPage()
        })

        EmojiData.categories.forEachIndexed { idx, category ->
            val selected = idx == currentEmojiCategory
            val tab = TextView(context).apply {
                text = category.icon
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                alpha = if (selected) 1f else 0.55f
                if (selected) {
                    background = createKeyDrawable(colorCharKey(), colorKeyShadow())
                }
                layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(2), 0, dp(2), 0)
                }
                setOnClickListener {
                    currentEmojiCategory = idx
                    rebuildPage()
                }
            }
            bottomBar.addView(tab)
        }

        bottomBar.addView(createBackspaceKeyView(weight = 1.5f))
        addView(bottomBar)
    }

    private fun showKeyPopup(anchor: View, label: String) {
        if (popupWindow == null) {
            val tv = TextView(context).apply {
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            }
            popupTextView = tv
            popupWindow = PopupWindow(tv, dp(48), dp(58), false).apply {
                isTouchable = false
                isClippingEnabled = false
                elevation = dp(6).toFloat()
            }
        }
        popupTextView?.apply {
            text = label
            setTextColor(colorText())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(8).toFloat()
                setColor(if (isDark) Color.parseColor("#636366") else Color.WHITE)
                setStroke(dp(1), if (isDark) Color.parseColor("#3A3A3C") else Color.parseColor("#D1D1D6"))
            }
        }
        if (anchor.windowToken == null) return
        val pw = popupWindow ?: return
        val xOff = (anchor.width - pw.width) / 2
        val yOff = -(anchor.height + pw.height + dp(4))
        try {
            if (pw.isShowing) {
                pw.update(anchor, xOff, yOff, pw.width, pw.height)
            } else {
                pw.showAsDropDown(anchor, xOff, yOff)
            }
        } catch (_: Exception) {
            // Ignore window token race during IME transitions
        }
    }

    private fun createSpacer(weight: Float): View {
        return View(context).apply {
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight)
        }
    }

    private fun createKeyDrawable(fillColor: Int, shadowColor: Int): Drawable {
        val radius = dp(5).toFloat()
        val shadow = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(shadowColor)
        }
        val face = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(fillColor)
        }
        return LayerDrawable(arrayOf(shadow, face)).apply {
            setLayerInset(1, 0, 0, 0, dp(1))
        }
    }

    private fun performHaptic() {
        if (prefs.hapticEnabled) {
            performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun colorBg(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_bg else R.color.ios_light_bg)
    private fun colorCharKey(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key else R.color.ios_light_key)
    private fun colorCharKeyPressed(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key_pressed else R.color.ios_light_key_pressed)
    private fun colorSpecialKey(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_special_key else R.color.ios_light_special_key)
    private fun colorSpecialKeyPressed(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_special_pressed else R.color.ios_light_special_pressed)
    private fun colorKeyShadow(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key_shadow else R.color.ios_light_key_shadow)
    private fun colorText(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_text else R.color.ios_light_text)
}
