package com.ioskeyboard.vn

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Low-latency, iOS-proportioned keyboard view (Light & Dark themes).
 * Uses in-layout popup overlay (no WindowManager IPC) and cached StateListDrawables
 * for instant, zero-lag key response.
 */
class IOSKeyboardView(
    context: Context,
    private val prefs: KeyboardPrefs,
    private val listener: KeyboardActionListener
) : FrameLayout(context) {

    interface KeyboardActionListener {
        fun onTextKey(text: String)
        fun onBackspace()
        fun onSpace()
        fun onEnter()
        fun onMoveCursor(delta: Int)
        fun onToggleLanguage()
        fun onSwitchImePicker()
        fun onKeyFeedback(type: FeedbackType)
    }

    enum class FeedbackType { CHARACTER, DELETE, SPACE, RETURN }
    enum class Page { LETTERS, NUMBERS, SYMBOLS, EMOJI }
    enum class ShiftState { OFF, ON, CAPS_LOCK }

    /** Transparent headroom above the keyboard so Row 1 key popups render with zero WindowManager IPC */
    val popupHeadroomPx: Int = dp(58)

    private val keyboardPanel: LinearLayout
    private val popupOverlay: TextView

    private var currentPage: Page = Page.LETTERS
    private var shiftState: ShiftState = ShiftState.OFF
    private var lastShiftTapTime: Long = 0L
    private var returnLabel: String = "nhập"
    private var returnIsBlue: Boolean = false
    private var isDark: Boolean = false
    private var currentEmojiCategory: Int = 0

    private val handler = Handler(Looper.getMainLooper())
    private var repeatDeleteRunnable: Runnable? = null

    private var spaceTrackpadActive = false
    private var spaceLastX = 0f
    private var spaceLongPressRunnable: Runnable? = null

    private val letterKeyViews = mutableListOf<TextView>()
    private var shiftButtonView: ImageView? = null
    private var spaceTextView: TextView? = null
    private var returnTextView: TextView? = null

    private val hidePopupRunnable = Runnable { popupOverlay.visibility = View.GONE }

    init {
        clipChildren = false
        clipToPadding = false
        isMotionEventSplittingEnabled = true

        keyboardPanel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isMotionEventSplittingEnabled = true
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT).apply {
                topMargin = popupHeadroomPx
            }
        }
        addView(keyboardPanel)

        popupOverlay = TextView(context).apply {
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 29f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            elevation = dp(6).toFloat()
            visibility = View.GONE
            layoutParams = LayoutParams(dp(46), dp(54))
        }
        addView(popupOverlay)

        refreshThemeAndBuild()
    }

    fun refreshThemeAndBuild() {
        isDark = resolveDarkMode()
        keyboardPanel.setBackgroundColor(colorBg())
        keyboardPanel.setPadding(dp(3), dp(8), dp(3), dp(6))
        stylePopupOverlay()
        rebuildPage()
    }

    private fun stylePopupOverlay() {
        popupOverlay.setTextColor(colorText())
        popupOverlay.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(8).toFloat()
            setColor(if (isDark) Color.parseColor("#636366") else Color.WHITE)
            setStroke(dp(1), if (isDark) Color.parseColor("#3A3A3C") else Color.parseColor("#D1D1D6"))
        }
    }

    fun setShiftState(state: ShiftState) {
        if (shiftState == state) return
        shiftState = state
        updateLetterCaseAndShiftIcon()
    }

    fun getShiftState(): ShiftState = shiftState

    fun setReturnAction(label: String, highlightBlue: Boolean) {
        returnLabel = label
        returnIsBlue = highlightBlue
        returnTextView?.let { tv ->
            tv.text = label
            tv.background = if (returnIsBlue) {
                createSelectorDrawable(Color.parseColor("#007AFF"), Color.parseColor("#0062CC"), colorKeyShadow())
            } else {
                createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            }
            tv.setTextColor(if (returnIsBlue) Color.WHITE else colorText())
        }
    }

    fun updateSpaceLabel() {
        spaceTextView?.text = if (prefs.telexEnabled) "dấu cách" else "space"
    }

    fun dismissPopup() {
        handler.removeCallbacks(hidePopupRunnable)
        popupOverlay.visibility = View.GONE
    }

    private fun resolveDarkMode(): Boolean {
        return when (prefs.themeMode) {
            KeyboardPrefs.THEME_LIGHT -> false
            KeyboardPrefs.THEME_DARK -> true
            else -> {
                val nightFlags = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                nightFlags == Configuration.UI_MODE_NIGHT_YES
            }
        }
    }

    private fun rebuildPage() {
        dismissPopup()
        keyboardPanel.removeAllViews()
        letterKeyViews.clear()
        shiftButtonView = null
        spaceTextView = null
        returnTextView = null

        when (currentPage) {
            Page.LETTERS -> buildLettersPage()
            Page.NUMBERS -> buildNumbersPage()
            Page.SYMBOLS -> buildSymbolsPage()
            Page.EMOJI -> buildEmojiPage()
        }
    }

    private fun buildLettersPage() {
        val rowNum = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val row3 = listOf("z", "x", "c", "v", "b", "n", "m")

        if (prefs.numberRowEnabled) {
            keyboardPanel.addView(createNumberRow(rowNum))
        }
        keyboardPanel.addView(createCharRow(row1, sideWeight = 0f, isLetterRow = true))
        keyboardPanel.addView(createCharRow(row2, sideWeight = 0.5f, isLetterRow = true))
        keyboardPanel.addView(createRow3Letters(row3))
        keyboardPanel.addView(createBottomRow(modeLabel = "123", targetModePage = Page.NUMBERS))
        updateLetterCaseAndShiftIcon()
    }

    private fun buildNumbersPage() {
        val row1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row2 = listOf("-", "/", ":", ";", "(", ")", "₫", "&", "@", "\"")
        val row3 = listOf(".", ",", "?", "!", "'")

        keyboardPanel.addView(createCharRow(row1, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createCharRow(row2, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createRow3Symbols("#+=", Page.SYMBOLS, row3))
        keyboardPanel.addView(createBottomRow(modeLabel = "ABC", targetModePage = Page.LETTERS))
    }

    private fun buildSymbolsPage() {
        val row1 = listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "=")
        val row2 = listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•")
        val row3 = listOf(".", ",", "?", "!", "'")

        keyboardPanel.addView(createCharRow(row1, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createCharRow(row2, sideWeight = 0f, isLetterRow = false))
        keyboardPanel.addView(createRow3Symbols("123", Page.NUMBERS, row3))
        keyboardPanel.addView(createBottomRow(modeLabel = "ABC", targetModePage = Page.LETTERS))
    }

    private fun createNumberRow(keys: List<String>): LinearLayout {
        val numHeight = (prefs.keyHeightDp * 0.80f).toInt().coerceAtLeast(30)
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isMotionEventSplittingEnabled = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(numHeight)
            ).apply {
                bottomMargin = dp(8)
            }
        }
        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = false)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            row.addView(tv)
        }
        return row
    }

    private fun createRowContainer(bottomMarginDp: Int = 11): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isMotionEventSplittingEnabled = true
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(prefs.keyHeightDp)
            ).apply {
                bottomMargin = dp(bottomMarginDp)
            }
        }
    }

    private fun createCharRow(keys: List<String>, sideWeight: Float, isLetterRow: Boolean): LinearLayout {
        val row = createRowContainer()
        if (sideWeight > 0f) {
            row.addView(createSpacer(sideWeight))
        }
        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = isLetterRow)
            if (isLetterRow) letterKeyViews.add(tv)
            row.addView(tv)
        }
        if (sideWeight > 0f) {
            row.addView(createSpacer(sideWeight))
        }
        return row
    }

    private fun createRow3Letters(keys: List<String>): LinearLayout {
        val row = createRowContainer()
        val shiftBtn = createShiftKeyView(weight = 1.32f)
        shiftButtonView = shiftBtn
        row.addView(shiftBtn)
        row.addView(createSpacer(0.18f))

        for (k in keys) {
            val tv = createCharKeyView(k, weight = 1f, isLetter = true)
            letterKeyViews.add(tv)
            row.addView(tv)
        }

        row.addView(createSpacer(0.18f))
        row.addView(createBackspaceKeyView(weight = 1.32f))
        return row
    }

    private fun createRow3Symbols(switchLabel: String, targetPage: Page, keys: List<String>): LinearLayout {
        val row = createRowContainer()
        row.addView(createSpecialTextKey(switchLabel, weight = 1.32f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = targetPage
            rebuildPage()
        })
        row.addView(createSpacer(0.18f))

        for (k in keys) {
            row.addView(createCharKeyView(k, weight = 1.4f, isLetter = false))
        }

        row.addView(createSpacer(0.18f))
        row.addView(createBackspaceKeyView(weight = 1.32f))
        return row
    }

    private fun createBottomRow(modeLabel: String, targetModePage: Page): LinearLayout {
        val row = createRowContainer(bottomMarginDp = 2)

        row.addView(createSpecialTextKey(modeLabel, weight = 1.35f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = targetModePage
            rebuildPage()
        })

        row.addView(createSpecialIconKey(R.drawable.ic_emoji, weight = 1.0f,
            onClick = {
                listener.onKeyFeedback(FeedbackType.CHARACTER)
                currentPage = Page.EMOJI
                rebuildPage()
            }
        ))

        row.addView(createSpecialIconKey(R.drawable.ic_globe, weight = 1.0f,
            onClick = {
                listener.onKeyFeedback(FeedbackType.CHARACTER)
                listener.onToggleLanguage()
                updateSpaceLabel()
            },
            onLongClick = {
                performHaptic()
                listener.onSwitchImePicker()
            }
        ))

        val spaceKey = createSpaceKeyView(weight = 4.4f)
        spaceTextView = spaceKey
        row.addView(spaceKey)

        val returnKey = createReturnKeyView(weight = 2.25f)
        returnTextView = returnKey
        row.addView(returnKey)

        return row
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createCharKeyView(baseChar: String, weight: Float, isLetter: Boolean): TextView {
        val tv = TextView(context).apply {
            text = baseChar
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (isLetter) 21.5f else 20f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createSelectorDrawable(colorCharKey(), colorCharKeyPressed(), colorKeyShadow())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

        tv.setOnTouchListener { view, event ->
            val currentLabel = (view as TextView).text.toString()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    if (prefs.popupEnabled) showKeyPopup(view, currentLabel)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    scheduleHidePopup()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(currentLabel)
                    if (isLetter && shiftState == ShiftState.ON) {
                        shiftState = ShiftState.OFF
                        updateLetterCaseAndShiftIcon()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    dismissPopup()
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createShiftKeyView(weight: Float): ImageView {
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }
        iv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    val now = System.currentTimeMillis()
                    shiftState = when (shiftState) {
                        ShiftState.OFF -> {
                            lastShiftTapTime = now
                            ShiftState.ON
                        }
                        ShiftState.ON -> {
                            if (now - lastShiftTapTime < 350L) ShiftState.CAPS_LOCK else ShiftState.OFF
                        }
                        ShiftState.CAPS_LOCK -> ShiftState.OFF
                    }
                    updateLetterCaseAndShiftIcon()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return iv
    }

    private fun updateLetterCaseAndShiftIcon() {
        val upper = shiftState != ShiftState.OFF
        for (tv in letterKeyViews) {
            val raw = tv.text.toString()
            val target = if (upper) raw.uppercase() else raw.lowercase()
            if (raw != target) {
                tv.text = target
            }
        }
        shiftButtonView?.let { iv ->
            val iconRes = when (shiftState) {
                ShiftState.OFF -> R.drawable.ic_shift_off
                ShiftState.ON -> R.drawable.ic_shift_on
                ShiftState.CAPS_LOCK -> R.drawable.ic_caps_lock
            }
            val drawable = ContextCompat.getDrawable(context, iconRes)?.mutate()
            if (shiftState == ShiftState.OFF) {
                iv.background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
                drawable?.setTint(colorText())
            } else {
                val activeBg = if (isDark) Color.parseColor("#EBEBF0") else Color.WHITE
                iv.background = createSelectorDrawable(activeBg, colorCharKeyPressed(), colorKeyShadow())
                drawable?.setTint(Color.BLACK)
            }
            iv.setImageDrawable(drawable)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createBackspaceKeyView(weight: Float): ImageView {
        val iv = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            val d = ContextCompat.getDrawable(context, R.drawable.ic_backspace)?.mutate()
            d?.setTint(colorText())
            setImageDrawable(d)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

        iv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.DELETE)
                    listener.onBackspace()
                    startRepeatDelete()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    stopRepeatDelete()
                    true
                }
                else -> false
            }
        }
        return iv
    }

    private fun startRepeatDelete() {
        stopRepeatDelete()
        val runnable = object : Runnable {
            override fun run() {
                listener.onBackspace()
                handler.postDelayed(this, 55L)
            }
        }
        repeatDeleteRunnable = runnable
        handler.postDelayed(runnable, 350L)
    }

    private fun stopRepeatDelete() {
        repeatDeleteRunnable?.let { handler.removeCallbacks(it) }
        repeatDeleteRunnable = null
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createSpaceKeyView(weight: Float): TextView {
        val tv = TextView(context).apply {
            text = if (prefs.telexEnabled) "dấu cách" else "space"
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createSelectorDrawable(colorCharKey(), colorCharKeyPressed(), colorKeyShadow())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

        val stepPx = dp(12).toFloat()
        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    spaceTrackpadActive = false
                    spaceLastX = event.x
                    val lp = Runnable {
                        spaceTrackpadActive = true
                        performHaptic()
                    }
                    spaceLongPressRunnable = lp
                    handler.postDelayed(lp, 280L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (spaceTrackpadActive) {
                        val dx = event.x - spaceLastX
                        if (abs(dx) >= stepPx) {
                            val steps = (dx / stepPx).toInt()
                            spaceLastX += steps * stepPx
                            listener.onMoveCursor(steps)
                            performHaptic()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    spaceLongPressRunnable?.let { handler.removeCallbacks(it) }
                    spaceLongPressRunnable = null
                    if (!spaceTrackpadActive && event.actionMasked == MotionEvent.ACTION_UP) {
                        performHaptic()
                        listener.onKeyFeedback(FeedbackType.SPACE)
                        listener.onSpace()
                    }
                    spaceTrackpadActive = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createReturnKeyView(weight: Float): TextView {
        val tv = TextView(context).apply {
            text = returnLabel
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = if (returnIsBlue) {
                createSelectorDrawable(Color.parseColor("#007AFF"), Color.parseColor("#0062CC"), colorKeyShadow())
            } else {
                createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            }
            setTextColor(if (returnIsBlue) Color.WHITE else colorText())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }

        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.RETURN)
                    listener.onEnter()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createSpecialTextKey(label: String, weight: Float, onClick: () -> Unit): TextView {
        val tv = TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(colorText())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
        }
        tv.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    performHaptic()
                    onClick()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    true
                }
                else -> false
            }
        }
        return tv
    }

    private fun createSpecialIconKey(
        iconRes: Int,
        weight: Float,
        onClick: () -> Unit,
        onLongClick: (() -> Unit)? = null
    ): ImageView {
        return ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER
            background = createSelectorDrawable(colorSpecialKey(), colorSpecialKeyPressed(), colorKeyShadow())
            val d = ContextCompat.getDrawable(context, iconRes)?.mutate()
            d?.setTint(colorText())
            setImageDrawable(d)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
            setOnClickListener {
                performHaptic()
                onClick()
            }
            if (onLongClick != null) {
                setOnLongClickListener {
                    onLongClick()
                    true
                }
            }
        }
    }

    private fun buildEmojiPage() {
        val numRowExtra = if (prefs.numberRowEnabled) dp((prefs.keyHeightDp * 0.80f).toInt().coerceAtLeast(30)) + dp(8) else 0
        val totalKeyboardHeight = dp(prefs.keyHeightDp) * 4 + dp(11) * 3 + dp(2) + numRowExtra
        val barHeight = dp(prefs.keyHeightDp)
        val gridAreaHeight = (totalKeyboardHeight - barHeight - dp(8)).coerceAtLeast(dp(140))

        val scrollView = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                gridAreaHeight
            ).apply {
                bottomMargin = dp(8)
            }
            isVerticalScrollBarEnabled = false
        }

        val grid = GridLayout(context).apply {
            columnCount = 8
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val emojis = EmojiData.categories[currentEmojiCategory].emojis
        for (emoji in emojis) {
            val cell = TextView(context).apply {
                text = emoji
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                setPadding(0, dp(6), 0, dp(6))
                layoutParams = GridLayout.LayoutParams().apply {
                    width = 0
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                }
                setOnClickListener {
                    performHaptic()
                    listener.onKeyFeedback(FeedbackType.CHARACTER)
                    listener.onTextKey(emoji)
                }
            }
            grid.addView(cell)
        }
        scrollView.addView(grid)
        keyboardPanel.addView(scrollView)

        val bottomBar = createRowContainer(bottomMarginDp = 2)
        bottomBar.addView(createSpecialTextKey("ABC", weight = 1.5f) {
            listener.onKeyFeedback(FeedbackType.CHARACTER)
            currentPage = Page.LETTERS
            rebuildPage()
        })

        EmojiData.categories.forEachIndexed { idx, category ->
            val selected = idx == currentEmojiCategory
            val tab = TextView(context).apply {
                text = category.icon
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                alpha = if (selected) 1f else 0.55f
                if (selected) {
                    background = createKeyDrawable(colorCharKey(), colorKeyShadow())
                }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                    setMargins(dp(2), 0, dp(2), 0)
                }
                setOnClickListener {
                    currentEmojiCategory = idx
                    rebuildPage()
                }
            }
            bottomBar.addView(tab)
        }

        bottomBar.addView(createBackspaceKeyView(weight = 1.5f))
        keyboardPanel.addView(bottomBar)
    }

    /** Instant in-layout key popup (zero WindowManager IPC) */
    private fun showKeyPopup(anchor: View, label: String) {
        handler.removeCallbacks(hidePopupRunnable)
        val row = anchor.parent as? View ?: return
        val x = keyboardPanel.left + row.left + anchor.left + (anchor.width - popupOverlay.layoutParams.width) / 2f
        val y = keyboardPanel.top + row.top + anchor.top - popupOverlay.layoutParams.height - dp(4).toFloat()
        val maxX = (width - popupOverlay.layoutParams.width - dp(2)).toFloat().coerceAtLeast(0f)

        popupOverlay.text = label
        popupOverlay.translationX = x.coerceIn(dp(2).toFloat(), maxX)
        popupOverlay.translationY = y.coerceAtLeast(dp(2).toFloat())
        popupOverlay.visibility = View.VISIBLE
        popupOverlay.bringToFront()
    }

    private fun scheduleHidePopup() {
        handler.removeCallbacks(hidePopupRunnable)
        handler.postDelayed(hidePopupRunnable, 45L)
    }

    private fun createSpacer(weight: Float): View {
        return View(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
        }
    }

    private fun createSelectorDrawable(normalColor: Int, pressedColor: Int, shadowColor: Int): Drawable {
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), createKeyDrawable(pressedColor, shadowColor))
            addState(intArrayOf(), createKeyDrawable(normalColor, shadowColor))
        }
    }

    private fun createKeyDrawable(fillColor: Int, shadowColor: Int): Drawable {
        val radius = dp(5).toFloat()
        val shadow = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(shadowColor)
        }
        val face = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(fillColor)
        }
        return LayerDrawable(arrayOf(shadow, face)).apply {
            setLayerInset(1, 0, 0, 0, dp(1))
        }
    }

    private fun performHaptic() {
        if (prefs.hapticEnabled) {
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun colorBg(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_bg else R.color.ios_light_bg)
    private fun colorCharKey(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key else R.color.ios_light_key)
    private fun colorCharKeyPressed(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key_pressed else R.color.ios_light_key_pressed)
    private fun colorSpecialKey(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_special_key else R.color.ios_light_special_key)
    private fun colorSpecialKeyPressed(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_special_pressed else R.color.ios_light_special_pressed)
    private fun colorKeyShadow(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_key_shadow else R.color.ios_light_key_shadow)
    private fun colorText(): Int = ContextCompat.getColor(context, if (isDark) R.color.ios_dark_text else R.color.ios_light_text)
}
