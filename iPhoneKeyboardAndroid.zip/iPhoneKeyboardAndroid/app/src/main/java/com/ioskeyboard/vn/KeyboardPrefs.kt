package com.ioskeyboard.vn

import android.content.Context
import android.content.SharedPreferences

class KeyboardPrefs(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ikey_vn_prefs", Context.MODE_PRIVATE)

    var numberRowEnabled: Boolean
        get() = prefs.getBoolean(KEY_NUMBER_ROW, true)
        set(value) = prefs.edit().putBoolean(KEY_NUMBER_ROW, value).apply()

    var telexEnabled: Boolean
        get() = prefs.getBoolean(KEY_TELEX, true)
        set(value) = prefs.edit().putBoolean(KEY_TELEX, value).apply()

    var popupEnabled: Boolean
        get() = prefs.getBoolean(KEY_POPUP, true)
        set(value) = prefs.edit().putBoolean(KEY_POPUP, value).apply()

    var hapticEnabled: Boolean
        get() = prefs.getBoolean(KEY_HAPTIC, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTIC, value).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND, false)
        set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

    var doubleSpacePeriod: Boolean
        get() = prefs.getBoolean(KEY_DOUBLE_SPACE, true)
        set(value) = prefs.edit().putBoolean(KEY_DOUBLE_SPACE, value).apply()

    /** 0 = Auto (system), 1 = Light, 2 = Dark */
    var themeMode: Int
        get() = prefs.getInt(KEY_THEME, THEME_AUTO)
        set(value) = prefs.edit().putInt(KEY_THEME, value).apply()

    /** Key height in dp: 38 (compact), 42 (iPhone standard), 46 (tall) */
    var keyHeightDp: Int
        get() = prefs.getInt(KEY_HEIGHT_DP, 42)
        set(value) = prefs.edit().putInt(KEY_HEIGHT_DP, value).apply()

    companion object {
        const val THEME_AUTO = 0
        const val THEME_LIGHT = 1
        const val THEME_DARK = 2

        private const val KEY_NUMBER_ROW = "number_row_enabled"
        private const val KEY_TELEX = "telex_enabled"
        private const val KEY_POPUP = "popup_enabled"
        private const val KEY_HAPTIC = "haptic_enabled"
        private const val KEY_SOUND = "sound_enabled"
        private const val KEY_DOUBLE_SPACE = "double_space_period"
        private const val KEY_THEME = "theme_mode"
        private const val KEY_HEIGHT_DP = "key_height_dp"
    }
}
