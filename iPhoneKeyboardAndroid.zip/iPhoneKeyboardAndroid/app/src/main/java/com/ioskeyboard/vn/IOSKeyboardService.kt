package com.ioskeyboard.vn

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.SystemClock
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager

class IOSKeyboardService : InputMethodService(), IOSKeyboardView.KeyboardActionListener {

    private lateinit var prefs: KeyboardPrefs
    private val telex = TelexEngine()
    private var keyboardView: IOSKeyboardView? = null
    private var audioManager: AudioManager? = null

    private var lastSpaceTime: Long = 0L
    private var lastCursorPos: Int = -1
    private var expectedCursorPos: Int = -1
    private var lastInternalEditUptime: Long = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    override fun onCreateInputView(): View {
        val view = IOSKeyboardView(this, prefs, this)
        keyboardView = view
        return view
    }

    override fun onComputeInsets(outInsets: Insets) {
        super.onComputeInsets(outInsets)
        val kv = keyboardView ?: return
        val headroom = kv.popupHeadroomPx
        outInsets.contentTopInsets += headroom
        outInsets.visibleTopInsets += headroom
        outInsets.touchableInsets = Insets.TOUCHABLE_INSETS_CONTENT
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        telex.reset()
        lastSpaceTime = 0L
        lastCursorPos = info?.initialSelEnd ?: -1
        expectedCursorPos = lastCursorPos
        lastInternalEditUptime = 0L
        keyboardView?.refreshThemeAndBuild()
        updateReturnKeyAppearance(info)
        updateAutoCapitalization(info)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        telex.reset()
        keyboardView?.dismissPopup()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        lastCursorPos = newSelEnd

        if (telex.isEmpty()) return

        // User highlighted a text range -> reset Telex buffer
        if (newSelStart != newSelEnd) {
            telex.reset()
            expectedCursorPos = newSelEnd
            return
        }

        // Cursor matches our own edit -> keep Telex buffer intact!
        if (newSelEnd == expectedCursorPos) {
            return
        }

        // Ignore async selection callbacks arriving right after fast typing
        if (SystemClock.uptimeMillis() - lastInternalEditUptime < 350L) {
            return
        }

        // User tapped elsewhere in the text box -> reset Telex buffer
        telex.reset()
        expectedCursorPos = newSelEnd
    }

    private fun trackCursorAfterEdit(deleted: Int, inserted: Int) {
        lastInternalEditUptime = SystemClock.uptimeMillis()
        val base = if (expectedCursorPos >= 0) expectedCursorPos else lastCursorPos
        if (base >= 0) {
            expectedCursorPos = (base - deleted).coerceAtLeast(0) + inserted
        }
    }

    override fun onTextKey(text: String) {
        val ic = currentInputConnection ?: return
        lastSpaceTime = 0L

        if (prefs.telexEnabled && text.length == 1 && isAsciiLetter(text[0])) {
            val update = telex.processLetter(text[0])
            trackCursorAfterEdit(update.deleteBeforeCursor, update.commitText.length)
            if (update.deleteBeforeCursor == 0) {
                ic.commitText(update.commitText, 1)
            } else {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(update.deleteBeforeCursor, 0)
                ic.commitText(update.commitText, 1)
                ic.endBatchEdit()
            }
        } else {
            telex.reset()
            trackCursorAfterEdit(0, text.length)
            ic.commitText(text, 1)
            if (text == "." || text == "!" || text == "?") {
                updateAutoCapitalization(currentInputEditorInfo)
            }
        }
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        lastSpaceTime = 0L

        if (prefs.telexEnabled && !telex.isEmpty()) {
            val update = telex.processBackspace()
            if (update != null) {
                trackCursorAfterEdit(update.deleteBeforeCursor, update.commitText.length)
                ic.beginBatchEdit()
                if (update.deleteBeforeCursor > 0) {
                    ic.deleteSurroundingText(update.deleteBeforeCursor, 0)
                }
                if (update.commitText.isNotEmpty()) {
                    ic.commitText(update.commitText, 1)
                }
                ic.endBatchEdit()
                return
            }
        }

        // Fast single-character / selected-text delete via standard DEL key event
        trackCursorAfterEdit(1, 0)
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        telex.reset()

        val now = SystemClock.uptimeMillis()
        if (prefs.doubleSpacePeriod && now - lastSpaceTime < 350L) {
            val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                trackCursorAfterEdit(1, 2)
                ic.beginBatchEdit()
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                ic.endBatchEdit()
                lastSpaceTime = 0L
                updateAutoCapitalization(currentInputEditorInfo)
                return
            }
        }

        lastSpaceTime = now
        trackCursorAfterEdit(0, 1)
        ic.commitText(" ", 1)
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        telex.reset()
        lastSpaceTime = 0L

        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val isMultiLine = ((info?.inputType ?: 0) and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0

        if (!isMultiLine && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            trackCursorAfterEdit(0, 1)
            ic.commitText("\n", 1)
            updateAutoCapitalization(info)
        }
    }

    override fun onMoveCursor(delta: Int) {
        val ic = currentInputConnection ?: return
        telex.reset()
        val keyCode = if (delta > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        repeat(kotlin.math.abs(delta)) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        }
    }

    override fun onToggleLanguage() {
        telex.reset()
        prefs.telexEnabled = !prefs.telexEnabled
    }

    override fun onSwitchImePicker() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showInputMethodPicker()
    }

    override fun onKeyFeedback(type: IOSKeyboardView.FeedbackType) {
        if (!prefs.soundEnabled) return
        val fx = when (type) {
            IOSKeyboardView.FeedbackType.CHARACTER -> AudioManager.FX_KEYPRESS_STANDARD
            IOSKeyboardView.FeedbackType.DELETE -> AudioManager.FX_KEYPRESS_DELETE
            IOSKeyboardView.FeedbackType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
            IOSKeyboardView.FeedbackType.RETURN -> AudioManager.FX_KEYPRESS_RETURN
        }
        audioManager?.playSoundEffect(fx, 0.5f)
    }

    private fun updateReturnKeyAppearance(info: EditorInfo?) {
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val isMultiLine = ((info?.inputType ?: 0) and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        if (isMultiLine) {
            keyboardView?.setReturnAction("nhập", highlightBlue = false)
            return
        }
        when (action) {
            EditorInfo.IME_ACTION_SEARCH -> keyboardView?.setReturnAction("tìm", highlightBlue = true)
            EditorInfo.IME_ACTION_GO -> keyboardView?.setReturnAction("đi", highlightBlue = true)
            EditorInfo.IME_ACTION_SEND -> keyboardView?.setReturnAction("gửi", highlightBlue = true)
            EditorInfo.IME_ACTION_NEXT -> keyboardView?.setReturnAction("tiếp", highlightBlue = false)
            EditorInfo.IME_ACTION_DONE -> keyboardView?.setReturnAction("xong", highlightBlue = true)
            else -> keyboardView?.setReturnAction("nhập", highlightBlue = false)
        }
    }

    private fun updateAutoCapitalization(info: EditorInfo?) {
        val kv = keyboardView ?: return
        if (kv.getShiftState() == IOSKeyboardView.ShiftState.CAPS_LOCK) return

        val ic = currentInputConnection ?: return
        val inputType = info?.inputType ?: 0
        val variation = inputType and InputType.TYPE_MASK_VARIATION
        val isNoCapField = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI

        if (isNoCapField) {
            kv.setShiftState(IOSKeyboardView.ShiftState.OFF)
            return
        }

        val capsMode = ic.getCursorCapsMode(inputType)
        kv.setShiftState(
            if (capsMode != 0) IOSKeyboardView.ShiftState.ON else IOSKeyboardView.ShiftState.OFF
        )
    }

    private fun isAsciiLetter(c: Char): Boolean = (c in 'a'..'z') || (c in 'A'..'Z')
}
