package com.ioskeyboard.vn

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat

class IOSKeyboardService : InputMethodService(), IOSKeyboardView.KeyboardActionListener {

    private lateinit var prefs: KeyboardPrefs
    private val telex = TelexEngine()
    private var keyboardView: IOSKeyboardView? = null
    private var audioManager: AudioManager? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListeningVoice: Boolean = false

    private var lastSpaceTime: Long = 0L
    private var lastCursorPos: Int = -1
    private var expectedCursorPos: Int = -1
    private var lastInternalEditUptime: Long = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = KeyboardPrefs(this)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    override fun onDestroy() {
        stopVoiceRecognition()
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val view = IOSKeyboardView(this, prefs, this)
        keyboardView = view
        return view
    }

    override fun onComputeInsets(outInsets: Insets) {
        super.onComputeInsets(outInsets)
        val kv = keyboardView ?: return
        val headroom = kv.popupHeadroomPx
        outInsets.contentTopInsets += headroom
        outInsets.visibleTopInsets += headroom
        outInsets.touchableInsets = Insets.TOUCHABLE_INSETS_CONTENT
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        stopVoiceRecognition()
        telex.reset()
        lastSpaceTime = 0L
        lastCursorPos = info?.initialSelEnd ?: -1
        expectedCursorPos = lastCursorPos
        lastInternalEditUptime = 0L
        keyboardView?.refreshThemeAndBuild()
        updateReturnKeyAppearance(info)
        updateAutoCapitalization(info)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopVoiceRecognition()
        telex.reset()
        keyboardView?.dismissPopup()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        lastCursorPos = newSelEnd

        if (telex.isEmpty()) return

        if (newSelStart != newSelEnd) {
            telex.reset()
            expectedCursorPos = newSelEnd
            return
        }

        if (newSelEnd == expectedCursorPos) {
            return
        }

        if (SystemClock.uptimeMillis() - lastInternalEditUptime < 350L) {
            return
        }

        telex.reset()
        expectedCursorPos = newSelEnd
    }

    private fun trackCursorAfterEdit(deleted: Int, inserted: Int) {
        lastInternalEditUptime = SystemClock.uptimeMillis()
        val base = if (expectedCursorPos >= 0) expectedCursorPos else lastCursorPos
        if (base >= 0) {
            expectedCursorPos = (base - deleted).coerceAtLeast(0) + inserted
        }
    }

    override fun onTextKey(text: String) {
        val ic = currentInputConnection ?: return
        lastSpaceTime = 0L

        if (prefs.telexEnabled && text.length == 1 && isAsciiLetter(text[0])) {
            val update = telex.processLetter(text[0])
            trackCursorAfterEdit(update.deleteBeforeCursor, update.commitText.length)
            if (update.deleteBeforeCursor == 0) {
                ic.commitText(update.commitText, 1)
            } else {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(update.deleteBeforeCursor, 0)
                ic.commitText(update.commitText, 1)
                ic.endBatchEdit()
            }
        } else {
            telex.reset()
            trackCursorAfterEdit(0, text.length)
            ic.commitText(text, 1)
            if (text == "." || text == "!" || text == "?") {
                updateAutoCapitalization(currentInputEditorInfo)
            }
        }
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        lastSpaceTime = 0L

        if (prefs.telexEnabled && !telex.isEmpty()) {
            val update = telex.processBackspace()
            if (update != null) {
                trackCursorAfterEdit(update.deleteBeforeCursor, update.commitText.length)
                ic.beginBatchEdit()
                if (update.deleteBeforeCursor > 0) {
                    ic.deleteSurroundingText(update.deleteBeforeCursor, 0)
                }
                if (update.commitText.isNotEmpty()) {
                    ic.commitText(update.commitText, 1)
                }
                ic.endBatchEdit()
                return
            }
        }

        trackCursorAfterEdit(1, 0)
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL))
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        telex.reset()

        val now = SystemClock.uptimeMillis()
        if (prefs.doubleSpacePeriod && now - lastSpaceTime < 350L) {
            val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
            if (before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                trackCursorAfterEdit(1, 2)
                ic.beginBatchEdit()
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                ic.endBatchEdit()
                lastSpaceTime = 0L
                updateAutoCapitalization(currentInputEditorInfo)
                return
            }
        }

        lastSpaceTime = now
        trackCursorAfterEdit(0, 1)
        ic.commitText(" ", 1)
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        telex.reset()
        lastSpaceTime = 0L

        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val isMultiLine = ((info?.inputType ?: 0) and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0

        if (!isMultiLine && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            trackCursorAfterEdit(0, 1)
            ic.commitText("\n", 1)
            updateAutoCapitalization(info)
        }
    }

    override fun onMoveCursor(delta: Int) {
        val ic = currentInputConnection ?: return
        telex.reset()
        val keyCode = if (delta > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        repeat(kotlin.math.abs(delta)) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        }
    }

    override fun onToggleLanguage() {
        telex.reset()
        prefs.telexEnabled = !prefs.telexEnabled
    }

    override fun onSwitchImePicker() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showInputMethodPicker()
    }

    /**
     * Voice-to-text input:
     * 1. If RECORD_AUDIO is granted, uses Android SpeechRecognizer inline (staying right on iKey VN,
     *    dictating directly into the active text box in Vietnamese or English).
     * 2. Otherwise tries switching to the system's Google Voice Typing IME if enabled.
     * 3. Otherwise opens MainActivity to grant Microphone permission in 1 tap.
     */
    override fun onVoiceInput() {
        telex.reset()

        if (isListeningVoice) {
            stopVoiceRecognition()
            return
        }

        val hasMicPerm = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasMicPerm && SpeechRecognizer.isRecognitionAvailable(this)) {
            startInlineVoiceRecognition()
            return
        }

        if (trySwitchToGoogleVoiceTyping()) {
            return
        }

        // Ask user to grant Microphone permission in MainActivity
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(MainActivity.EXTRA_REQUEST_MIC, true)
            }
            startActivity(intent)
        } catch (_: Exception) {
        }
    }

    private fun startInlineVoiceRecognition() {
        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            isListeningVoice = true
                            keyboardView?.setVoiceListening(true)
                        }

                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            isListeningVoice = false
                            keyboardView?.setVoiceListening(false)
                        }

                        override fun onError(error: Int) {
                            isListeningVoice = false
                            keyboardView?.setVoiceListening(false)
                        }

                        override fun onResults(results: Bundle?) {
                            isListeningVoice = false
                            keyboardView?.setVoiceListening(false)
                            val spoken = results
                                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                ?.firstOrNull()
                                ?.trim()
                            if (!spoken.isNullOrEmpty()) {
                                val ic = currentInputConnection ?: return
                                val before = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
                                val prefix = if (before.isNotEmpty() && !before[0].isWhitespace()) " " else ""
                                val outText = prefix + spoken
                                trackCursorAfterEdit(0, outText.length)
                                ic.commitText(outText, 1)
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }

            val lang = if (prefs.telexEnabled) "vi-VN" else "en-US"
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            isListeningVoice = true
            keyboardView?.setVoiceListening(true)
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            isListeningVoice = false
            keyboardView?.setVoiceListening(false)
        }
    }

    private fun stopVoiceRecognition() {
        if (isListeningVoice) {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
        }
        isListeningVoice = false
        keyboardView?.setVoiceListening(false)
    }

    private fun trySwitchToGoogleVoiceTyping(): Boolean {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager ?: return false
        for (imi in imm.enabledInputMethodList) {
            for (i in 0 until imi.subtypeCount) {
                val subtype = imi.getSubtypeAt(i)
                if (subtype.mode.equals("voice", ignoreCase = true)) {
                    try {
                        switchInputMethod(imi.id, subtype)
                        return true
                    } catch (_: Exception) {
                    }
                }
            }
        }
        return false
    }

    override fun onKeyFeedback(type: IOSKeyboardView.FeedbackType) {
        if (!prefs.soundEnabled) return
        val fx = when (type) {
            IOSKeyboardView.FeedbackType.CHARACTER -> AudioManager.FX_KEYPRESS_STANDARD
            IOSKeyboardView.FeedbackType.DELETE -> AudioManager.FX_KEYPRESS_DELETE
            IOSKeyboardView.FeedbackType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
            IOSKeyboardView.FeedbackType.RETURN -> AudioManager.FX_KEYPRESS_RETURN
        }
        audioManager?.playSoundEffect(fx, 0.5f)
    }

    private fun updateReturnKeyAppearance(info: EditorInfo?) {
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val isMultiLine = ((info?.inputType ?: 0) and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0
        if (isMultiLine) {
            keyboardView?.setReturnAction("nhập", highlightBlue = false)
            return
        }
        when (action) {
            EditorInfo.IME_ACTION_SEARCH -> keyboardView?.setReturnAction("tìm", highlightBlue = true)
            EditorInfo.IME_ACTION_GO -> keyboardView?.setReturnAction("đi", highlightBlue = true)
            EditorInfo.IME_ACTION_SEND -> keyboardView?.setReturnAction("gửi", highlightBlue = true)
            EditorInfo.IME_ACTION_NEXT -> keyboardView?.setReturnAction("tiếp", highlightBlue = false)
            EditorInfo.IME_ACTION_DONE -> keyboardView?.setReturnAction("xong", highlightBlue = true)
            else -> keyboardView?.setReturnAction("nhập", highlightBlue = false)
        }
    }

    private fun updateAutoCapitalization(info: EditorInfo?) {
        val kv = keyboardView ?: return
        if (kv.getShiftState() == IOSKeyboardView.ShiftState.CAPS_LOCK) return

        val ic = currentInputConnection ?: return
        val inputType = info?.inputType ?: 0
        val variation = inputType and InputType.TYPE_MASK_VARIATION
        val isNoCapField = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI

        if (isNoCapField) {
            kv.setShiftState(IOSKeyboardView.ShiftState.OFF)
            return
        }

        val capsMode = ic.getCursorCapsMode(inputType)
        kv.setShiftState(
            if (capsMode != 0) IOSKeyboardView.ShiftState.ON else IOSKeyboardView.ShiftState.OFF
        )
    }

    private fun isAsciiLetter(c: Char): Boolean = (c in 'a'..'z') || (c in 'A'..'Z')
}
