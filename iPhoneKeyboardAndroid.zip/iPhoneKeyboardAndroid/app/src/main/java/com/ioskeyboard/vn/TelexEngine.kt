package com.ioskeyboard.vn

/**
 * Pure Vietnamese Telex IME engine (no suggestions, no autocorrect, no swipe).
 *
 * Supported rules:
 * - Vowel & consonant modifiers: aw->ă, aa->â, ee->ê, oo->ô, ow->ơ, uw->ư, dd->đ, standalone w->ư
 * - Compound horn rule: uo + w -> ươ (e.g. duowng -> dương, nguowif -> người, thuowng -> thương)
 * - Free-typing tone marks: s (sắc), f (huyền), r (hỏi), x (ngã), j (nặng), z (xóa dấu)
 * - Dynamic tone repositioning as the syllable grows (e.g. hoaf -> hòa, hoafn -> hoàn)
 * - Double-key undo for both modifiers (aa + a -> aa) and tones (as + s -> as)
 * - Full uppercase / mixed-case preservation
 */
class TelexEngine {

    enum class Tone(val index: Int) {
        NONE(0),
        ACUTE(1),    // s - sắc
        GRAVE(2),    // f - huyền
        HOOK(3),     // r - hỏi
        TILDE(4),    // x - ngã
        DOT(5)       // j - nặng
    }

    data class TelexUpdate(
        val deleteBeforeCursor: Int,
        val commitText: String
    )

    private data class CharEntry(
        var base: Char,     // lowercase: a, ă, â, e, ê, i, o, ô, ơ, u, ư, y, d, đ, or consonant
        var isUpper: Boolean
    )

    private val entries = mutableListOf<CharEntry>()
    private var currentTone: Tone = Tone.NONE
    private var lastRendered: String = ""

    // Tracks undo states so a 3rd key press doesn't re-trigger immediately
    private val escapedModifiers = mutableSetOf<Char>()
    private var escapedTone: Boolean = false
    private var autoConvertedOFromUwo: Boolean = false

    val currentWord: String
        get() = lastRendered

    fun reset() {
        entries.clear()
        currentTone = Tone.NONE
        lastRendered = ""
        escapedModifiers.clear()
        escapedTone = false
        autoConvertedOFromUwo = false
    }

    fun isEmpty(): Boolean = entries.isEmpty()

    /**
     * Feeds a single ASCII letter into the Telex syllable buffer.
     * Non-letter characters should call reset() and commit directly.
     */
    fun processLetter(ch: Char): TelexUpdate {
        val lower = ch.lowercaseChar()
        val isUpper = ch.isUpperCase()
        val prevLen = lastRendered.length

        // 1. Handle 'z' (remove tone)
        if (lower == 'z' && currentTone != Tone.NONE && !escapedTone) {
            currentTone = Tone.NONE
            return buildUpdate(prevLen)
        }

        // 2. Handle tone keys: s, f, r, x, j (only if syllable already has a vowel)
        val toneFromKey = toneForKey(lower)
        if (toneFromKey != null && hasVowel() && !escapedTone) {
            if (currentTone == toneFromKey) {
                // Double-tap same tone -> undo tone and append literal key
                currentTone = Tone.NONE
                escapedTone = true
                entries.add(CharEntry(lower, isUpper))
                return buildUpdate(prevLen)
            } else {
                currentTone = toneFromKey
                return buildUpdate(prevLen)
            }
        }

        // 3. Handle 'd' -> 'đ' (or undo 'đ' -> 'dd')
        if (lower == 'd' && !escapedModifiers.contains('d')) {
            val dIdx = entries.indexOfFirst { it.base == 'd' || it.base == 'đ' }
            if (dIdx == 0) {
                val target = entries[0]
                if (target.base == 'd') {
                    target.base = 'đ'
                    return buildUpdate(prevLen)
                } else if (target.base == 'đ') {
                    target.base = 'd'
                    escapedModifiers.add('d')
                    entries.add(CharEntry('d', isUpper))
                    return buildUpdate(prevLen)
                }
            }
        }

        // 4. Handle circumflex keys: a->â, e->ê, o->ô (or undo)
        if ((lower == 'a' || lower == 'e' || lower == 'o') && !escapedModifiers.contains(lower)) {
            val circumflex = when (lower) {
                'a' -> 'â'
                'e' -> 'ê'
                else -> 'ô'
            }
            val idx = entries.indexOfLast { it.base == lower || it.base == circumflex }
            if (idx >= 0) {
                val target = entries[idx]
                if (target.base == lower) {
                    target.base = circumflex
                    return buildUpdate(prevLen)
                } else if (target.base == circumflex) {
                    target.base = lower
                    escapedModifiers.add(lower)
                    entries.add(CharEntry(lower, isUpper))
                    return buildUpdate(prevLen)
                }
            }
        }

        // 5. Handle 'w' -> ă, ơ, ư, ươ, or standalone ư (or undo)
        if (lower == 'w' && !escapedModifiers.contains('w')) {
            // Check compound "uo" -> "ươ" (e.g. uow, uongw, uoiw, uocw)
            val uoIdx = findUoPairIndex()
            if (uoIdx >= 0) {
                val uEntry = entries[uoIdx]
                val oEntry = entries[uoIdx + 1]
                if (uEntry.base == 'u' && oEntry.base == 'o') {
                    uEntry.base = 'ư'
                    oEntry.base = 'ơ'
                    return buildUpdate(prevLen)
                } else if (uEntry.base == 'ư' && oEntry.base == 'ơ') {
                    if (autoConvertedOFromUwo) {
                        autoConvertedOFromUwo = false
                        return buildUpdate(prevLen)
                    }
                    uEntry.base = 'u'
                    oEntry.base = 'o'
                    escapedModifiers.add('w')
                    entries.add(CharEntry('w', isUpper))
                    return buildUpdate(prevLen)
                } else if (uEntry.base == 'u' && oEntry.base == 'ơ') {
                    uEntry.base = 'ư'
                    return buildUpdate(prevLen)
                } else if (uEntry.base == 'ư' && oEntry.base == 'o') {
                    oEntry.base = 'ơ'
                    return buildUpdate(prevLen)
                }
            }

            // Check single modifiable vowel: a<->ă, o<->ơ, u<->ư
            // Note: in "qu", 'u' is part of the initial consonant if followed by another vowel
            val modIdx = findLastWModifiableVowel()
            if (modIdx >= 0) {
                val target = entries[modIdx]
                when (target.base) {
                    'a' -> { target.base = 'ă'; return buildUpdate(prevLen) }
                    'o' -> { target.base = 'ơ'; return buildUpdate(prevLen) }
                    'u' -> { target.base = 'ư'; return buildUpdate(prevLen) }
                    'ă' -> {
                        target.base = 'a'
                        escapedModifiers.add('w')
                        entries.add(CharEntry('w', isUpper))
                        return buildUpdate(prevLen)
                    }
                    'ơ' -> {
                        target.base = 'o'
                        escapedModifiers.add('w')
                        entries.add(CharEntry('w', isUpper))
                        return buildUpdate(prevLen)
                    }
                    'ư' -> {
                        // If standalone 'ư' was originally typed via 'w', undo back to 'w'
                        // Otherwise revert 'ư' -> 'u' and append 'w'
                        if (entries.size == 1 || (modIdx == entries.lastIndex && isConsonantOnlyBefore(modIdx))) {
                            target.base = 'w'
                            escapedModifiers.add('w')
                            return buildUpdate(prevLen)
                        } else {
                            target.base = 'u'
                            escapedModifiers.add('w')
                            entries.add(CharEntry('w', isUpper))
                            return buildUpdate(prevLen)
                        }
                    }
                }
            } else {
                // Standalone 'w' -> 'ư' (e.g. "w" -> "ư", "tw" -> "tư", "ngw" -> "ngư")
                entries.add(CharEntry('ư', isUpper))
                return buildUpdate(prevLen)
            }
        }

        // 6. Regular letter append
        entries.add(CharEntry(lower, isUpper))
        // Auto-convert "ưo" -> "ươ" if user typed "uw" then "o" (e.g. "duwong" -> "dương")
        autoFixUwoCompound()
        return buildUpdate(prevLen)
    }

    /**
     * Handles Backspace within the active Telex syllable.
     * Returns null if buffer is empty (caller should perform standard single-char delete).
     */
    fun processBackspace(): TelexUpdate? {
        if (entries.isEmpty()) return null
        val prevLen = lastRendered.length
        entries.removeAt(entries.lastIndex)
        if (!hasVowel()) {
            currentTone = Tone.NONE
        }
        escapedModifiers.clear()
        escapedTone = false
        return buildUpdate(prevLen)
    }

    private fun autoFixUwoCompound() {
        for (i in 0 until entries.size - 1) {
            if (entries[i].base == 'ư' && entries[i + 1].base == 'o') {
                // Only convert if not preceded by 'q'
                val isQu = i > 0 && entries[i - 1].base == 'q'
                if (!isQu) {
                    entries[i + 1].base = 'ơ'
                    autoConvertedOFromUwo = true
                }
            }
        }
    }

    private fun isConsonantOnlyBefore(idx: Int): Boolean {
        for (i in 0 until idx) {
            if (isVowelBase(entries[i].base)) return false
        }
        return true
    }

    private fun findUoPairIndex(): Int {
        for (i in 0 until entries.size - 1) {
            val c1 = entries[i].base
            val c2 = entries[i + 1].base
            val isQu = i > 0 && entries[i - 1].base == 'q'
            if (!isQu && (c1 == 'u' || c1 == 'ư') && (c2 == 'o' || c2 == 'ơ')) {
                return i
            }
        }
        return -1
    }

    private fun findLastWModifiableVowel(): Int {
        for (i in entries.indices.reversed()) {
            val c = entries[i].base
            if (c == 'a' || c == 'ă' || c == 'o' || c == 'ơ' || c == 'u' || c == 'ư') {
                // Skip 'u' in "qu" if another vowel follows
                if (c == 'u' && i > 0 && entries[i - 1].base == 'q' && i < entries.lastIndex && isVowelBase(entries[i + 1].base)) {
                    continue
                }
                return i
            }
        }
        return -1
    }

    private fun hasVowel(): Boolean = entries.any { isVowelBase(it.base) }

    private fun buildUpdate(prevLen: Int): TelexUpdate {
        val rendered = render()
        lastRendered = rendered
        return TelexUpdate(deleteBeforeCursor = prevLen, commitText = rendered)
    }

    private fun render(): String {
        if (entries.isEmpty()) return ""
        val toneIdx = if (currentTone != Tone.NONE) findToneTargetIndex() else -1
        val sb = StringBuilder(entries.size)
        for (i in entries.indices) {
            val entry = entries[i]
            val ch = if (i == toneIdx) applyTone(entry.base, currentTone) else entry.base
            sb.append(if (entry.isUpper) ch.uppercaseChar() else ch)
        }
        return sb.toString()
    }

    /**
     * Standard modern Vietnamese tone placement:
     * 1. Exclude 'u' in "qu" and 'i' in "gi" when followed by another vowel.
     * 2. If a modified vowel (â, ă, ê, ô, ơ, ư) exists, place tone on it (prefer ơ in ươ).
     * 3. 3 vowels -> middle vowel.
     * 4. 2 vowels -> if followed by final consonant, 2nd vowel; else for oa/oe/uy -> 2nd vowel, otherwise 1st vowel.
     * 5. 1 vowel -> that vowel.
     */
    private fun findToneTargetIndex(): Int {
        val vowelIndices = mutableListOf<Int>()
        for (i in entries.indices) {
            if (isVowelBase(entries[i].base)) {
                vowelIndices.add(i)
            }
        }
        if (vowelIndices.isEmpty()) return -1

        // Filter out 'u' in "qu..." and 'i' in "gi..." when followed by another vowel
        val effectiveVowels = vowelIndices.filterNot { idx ->
            val c = entries[idx].base
            val hasNextVowel = vowelIndices.any { it > idx }
            (c == 'u' && idx == 1 && entries[0].base == 'q' && hasNextVowel) ||
                (c == 'i' && idx == 1 && entries[0].base == 'g' && hasNextVowel)
        }.ifEmpty { vowelIndices }

        if (effectiveVowels.size == 1) return effectiveVowels[0]

        // Prefer 'ơ' in "ươ"
        for (idx in effectiveVowels) {
            if (entries[idx].base == 'ơ') return idx
        }
        // Prefer any other modified vowel (ê, ô, â, ă, ư)
        val priorityModified = effectiveVowels.firstOrNull { entries[it].base in setOf('ê', 'ô', 'â', 'ă') }
        if (priorityModified != null) return priorityModified

        val lastVowelIdx = effectiveVowels.last()
        val hasFinalConsonant = lastVowelIdx < entries.lastIndex

        if (effectiveVowels.size >= 3) {
            return effectiveVowels[1]
        }

        // Exactly 2 effective vowels
        val v1 = entries[effectiveVowels[0]].base
        val v2 = entries[effectiveVowels[1]].base
        if (hasFinalConsonant) {
            return effectiveVowels[1]
        }

        // Open 2-vowel syllable: oa, oe, uy take tone on 2nd vowel (hòa, khỏe, thủy)
        val pair = "$v1$v2"
        return if (pair == "oa" || pair == "oe" || pair == "uy") {
            effectiveVowels[1]
        } else {
            effectiveVowels[0]
        }
    }

    companion object {
        private val VOWEL_TABLE: Map<Char, String> = mapOf(
            'a' to "aáàảãạ",
            'ă' to "ăắằẳẵặ",
            'â' to "âấầẩẫậ",
            'e' to "eéèẻẽẹ",
            'ê' to "êếềểễệ",
            'i' to "iíìỉĩị",
            'o' to "oóòỏõọ",
            'ô' to "ôốồổỗộ",
            'ơ' to "ơớờởỡợ",
            'u' to "uúùủũụ",
            'ư' to "ưứừửữự",
            'y' to "yýỳỷỹỵ"
        )

        fun isVowelBase(c: Char): Boolean = VOWEL_TABLE.containsKey(c)

        fun applyTone(base: Char, tone: Tone): Char {
            val row = VOWEL_TABLE[base] ?: return base
            return row[tone.index]
        }

        fun toneForKey(c: Char): Tone? = when (c) {
            's' -> Tone.ACUTE
            'f' -> Tone.GRAVE
            'r' -> Tone.HOOK
            'x' -> Tone.TILDE
            'j' -> Tone.DOT
            else -> null
        }
    }
}
