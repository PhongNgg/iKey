package com.ioskeyboard.vn

/**
 * Pure Vietnamese Telex IME engine (no suggestions, no autocorrect, no swipe).
 */
class TelexEngine {

    enum class Tone(val index: Int) {
        NONE(0),
        ACUTE(1),    // s - sắc
        GRAVE(2),    // f - huyền
        HOOK(3),     // r - hỏi
        TILDE(4),    // x - ngã
        DOT(5)       // j - nặng
    }

    data class TelexUpdate(
        val deleteBeforeCursor: Int,
        val commitText: String
    )

    private data class CharEntry(
        var base: Char,
        var isUpper: Boolean
    )

    private val entries = mutableListOf<CharEntry>()
    private var currentTone: Tone = Tone.NONE
    private var lastRendered: String = ""

    private val escapedModifiers = mutableSetOf<Char>()
    private var escapedTone: Boolean = false
    private var autoConvertedOFromUwo: Boolean = false

    val currentWord: String
        get() = lastRendered

    fun reset() {
        entries.clear()
        currentTone = Tone.NONE
        lastRendered = ""
        escapedModifiers.clear()
        escapedTone = false
        autoConvertedOFromUwo = false
    }

    fun isEmpty(): Boolean = entries.isEmpty()

    fun processLetter(ch: Char): TelexUpdate {
        val lower = ch.lowercaseChar()
        val isUpper = ch.isUpperCase()
        val prevLen = lastRendered.length

        // 1. Handle 'z' (remove tone)
        if (lower == 'z' && currentTone != Tone.NONE && !escapedTone) {
            currentTone = Tone.NONE
            return buildUpdate(prevLen)
        }

        // 2. Handle tone keys: s, f, r, x, j
        val toneFromKey = toneForKey(lower)
        if (toneFromKey != null && hasVowel() && !escapedTone) {
            if (currentTone == toneFromKey) {
                currentTone = Tone.NONE
                escapedTone = true
                entries.add(CharEntry(lower, isUpper))
                return buildUpdate(prevLen)
            } else {
                currentTone = toneFromKey
                return buildUpdate(prevLen)
            }
        }

        // 3. Handle 'd' -> 'đ' (or undo 'đ' -> 'dd')
        if (lower == 'd' && !escapedModifiers.contains('d')) {
            val dIdx = entries.indexOfFirst { it.base == 'd' || it.base == 'đ' }
            if (dIdx == 0) {
                val target = entries[0]
                if (target.base == 'd') {
                    target.base = 'đ'
                    return buildUpdate(prevLen)
                } else if (target.base == 'đ') {
                    target.base = 'd'
                    escapedModifiers.add('d')
                    entries.add(CharEntry('d', isUpper))
                    return buildUpdate(prevLen)
                }
            }
        }

        // 4. Handle circumflex keys: a->â, e->ê, o->ô (or undo)
        if ((lower == 'a' || lower == 'e' || lower == 'o') && !escapedModifiers.contains(lower)) {
            val circumflex = when (lower) {
                'a' -> 'â'
                'e' -> 'ê'
                else -> 'ô'
            }
            val idx = entries.indexOfLast { it.base == lower || it.base == circumflex }
            if (idx >= 0) {
                val target = entries[idx]
                if (target.base == lower) {
                    target.base = circumflex
                    return buildUpdate(prevLen)
                } else if (target.base == circumflex) {
                    target.base = lower
                    escapedModifiers.add(lower)
                    entries.add(CharEntry(lower, isUpper))
                    return buildUpdate(prevLen)
                }
            }
        }

        // 5. Handle 'w' -> ă, ơ, ư, ươ, or standalone ư (or undo)
        if (lower == 'w' && !escapedModifiers.contains('w')) {
            val uoIdx = findUoPairIndex()
            if (uoIdx >= 0) {
                val uEntry = entries[uoIdx]
                val oEntry = entries[uoIdx + 1]
                if (uEntry.base == 'u' && oEntry.base == 'o') {
                    uEntry.base = 'ư'
                    oEntry.base = 'ơ'
                    return buildUpdate(prevLen)
                } else if (uEntry.base == 'ư' && oEntry.base == 'ơ') {
                    if (autoConvertedOFromUwo) {
                        autoConvertedOFromUwo = false
                        return buildUpdate(prevLen)
                    }
                    uEntry.base = 'u'
                    oEntry.base = 'o'
                    escapedModifiers.add('w')
                    entries.add(CharEntry('w', isUpper))
                    return buildUpdate(prevLen)
                } else if (uEntry.base == 'u' && oEntry.base == 'ơ') {
                    uEntry.base = 'ư'
                    return buildUpdate(prevLen)
                } else if (uEntry.base == 'ư' && oEntry.base == 'o') {
                    oEntry.base = 'ơ'
                    return buildUpdate(prevLen)
                }
            }

            val modIdx = findLastWModifiableVowel()
            if (modIdx >= 0) {
                val target = entries[modIdx]
                when (target.base) {
                    'a' -> { target.base = 'ă'; return buildUpdate(prevLen) }
                    'o' -> { target.base = 'ơ'; return buildUpdate(prevLen) }
                    'u' -> { target.base = 'ư'; return buildUpdate(prevLen) }
                    'ă' -> {
                        target.base = 'a'
                        escapedModifiers.add('w')
                        entries.add(CharEntry('w', isUpper))
                        return buildUpdate(prevLen)
                    }
                    'ơ' -> {
                        target.base = 'o'
                        escapedModifiers.add('w')
                        entries.add(CharEntry('w', isUpper))
                        return buildUpdate(prevLen)
                    }
                    'ư' -> {
                        if (entries.size == 1 || (modIdx == entries.lastIndex && isConsonantOnlyBefore(modIdx))) {
                            target.base = 'w'
                            escapedModifiers.add('w')
                            return buildUpdate(prevLen)
                        } else {
                            target.base = 'u'
                            escapedModifiers.add('w')
                            entries.add(CharEntry('w', isUpper))
                            return buildUpdate(prevLen)
                        }
                    }
                }
            } else {
                entries.add(CharEntry('ư', isUpper))
                return buildUpdate(prevLen)
            }
        }

        // 6. Regular letter append
        entries.add(CharEntry(lower, isUpper))
        autoFixUwoCompound()
        return buildUpdate(prevLen)
    }

    fun processBackspace(): TelexUpdate? {
        if (entries.isEmpty()) return null
        val prevLen = lastRendered.length
        entries.removeAt(entries.lastIndex)
        if (!hasVowel()) {
            currentTone = Tone.NONE
        }
        escapedModifiers.clear()
        escapedTone = false
        autoConvertedOFromUwo = false
        return buildUpdate(prevLen)
    }

    private fun autoFixUwoCompound() {
        for (i in 0 until entries.size - 1) {
            if (entries[i].base == 'ư' && entries[i + 1].base == 'o') {
                val isQu = i > 0 && entries[i - 1].base == 'q'
                if (!isQu) {
                    entries[i + 1].base = 'ơ'
                    autoConvertedOFromUwo = true
                }
            }
        }
    }

    private fun isConsonantOnlyBefore(idx: Int): Boolean {
        for (i in 0 until idx) {
            if (isVowelBase(entries[i].base)) return false
        }
        return true
    }

    private fun findUoPairIndex(): Int {
        for (i in 0 until entries.size - 1) {
            val c1 = entries[i].base
            val c2 = entries[i + 1].base
            val isQu = i > 0 && entries[i - 1].base == 'q'
            if (!isQu && (c1 == 'u' || c1 == 'ư') && (c2 == 'o' || c2 == 'ơ')) {
                return i
            }
        }
        return -1
    }

    private fun findLastWModifiableVowel(): Int {
        for (i in entries.indices.reversed()) {
            val c = entries[i].base
            if (c == 'a' || c == 'ă' || c == 'o' || c == 'ơ' || c == 'u' || c == 'ư') {
                // Skip 'u' in "qu..." when followed by another vowel (e.g. quawn -> quăn)
                if (c == 'u' && i > 0 && entries[i - 1].base == 'q' && i < entries.lastIndex && isVowelBase(entries[i + 1].base)) {
                    continue
                }
                // In "ua" (not "qua"), 'w' modifies 'u' -> 'ư' (e.g. muaw -> mưa, suawr -> sửa)
                if (c == 'a' && i > 0 && (entries[i - 1].base == 'u' || entries[i - 1].base == 'ư')) {
                    val isQu = i >= 2 && entries[i - 2].base == 'q'
                    if (!isQu) continue
                }
                return i
            }
        }
        return -1
    }

    private fun hasVowel(): Boolean = entries.any { isVowelBase(it.base) }

    private fun buildUpdate(prevLen: Int): TelexUpdate {
        val rendered = render()
        lastRendered = rendered
        return TelexUpdate(deleteBeforeCursor = prevLen, commitText = rendered)
    }

    private fun render(): String {
        if (entries.isEmpty()) return ""
        val toneIdx = if (currentTone != Tone.NONE) findToneTargetIndex() else -1
        val sb = StringBuilder(entries.size)
        for (i in entries.indices) {
            val entry = entries[i]
            val ch = if (i == toneIdx) applyTone(entry.base, currentTone) else entry.base
            sb.append(if (entry.isUpper) ch.uppercaseChar() else ch)
        }
        return sb.toString()
    }

    private fun findToneTargetIndex(): Int {
        val vowelIndices = mutableListOf<Int>()
        for (i in entries.indices) {
            if (isVowelBase(entries[i].base)) {
                vowelIndices.add(i)
            }
        }
        if (vowelIndices.isEmpty()) return -1

        val effectiveVowels = vowelIndices.filterNot { idx ->
            val c = entries[idx].base
            val hasNextVowel = vowelIndices.any { it > idx }
            (c == 'u' && idx == 1 && entries[0].base == 'q' && hasNextVowel) ||
                (c == 'i' && idx == 1 && entries[0].base == 'g' && hasNextVowel)
        }.ifEmpty { vowelIndices }

        if (effectiveVowels.size == 1) return effectiveVowels[0]

        for (idx in effectiveVowels) {
            if (entries[idx].base == 'ơ') return idx
        }
        val priorityModified = effectiveVowels.firstOrNull { entries[it].base in setOf('ê', 'ô', 'â', 'ă') }
        if (priorityModified != null) return priorityModified

        val lastVowelIdx = effectiveVowels.last()
        val hasFinalConsonant = lastVowelIdx < entries.lastIndex

        if (effectiveVowels.size >= 3) {
            return effectiveVowels[1]
        }

        val v1 = entries[effectiveVowels[0]].base
        val v2 = entries[effectiveVowels[1]].base
        if (hasFinalConsonant) {
            return effectiveVowels[1]
        }

        val pair = "$v1$v2"
        return if (pair == "oa" || pair == "oe" || pair == "uy") {
            effectiveVowels[1]
        } else {
            effectiveVowels[0]
        }
    }

    companion object {
        private val VOWEL_TABLE: Map<Char, String> = mapOf(
            'a' to "aáàảãạ",
            'ă' to "ăắằẳẵặ",
            'â' to "âấầẩẫậ",
            'e' to "eéèẻẽẹ",
            'ê' to "êếềểễệ",
            'i' to "iíìỉĩị",
            'o' to "oóòỏõọ",
            'ô' to "ôốồổỗộ",
            'ơ' to "ơớờởỡợ",
            'u' to "uúùủũụ",
            'ư' to "ưứừửữự",
            'y' to "yýỳỷỹỵ"
        )

        fun isVowelBase(c: Char): Boolean = VOWEL_TABLE.containsKey(c)

        fun applyTone(base: Char, tone: Tone): Char {
            val row = VOWEL_TABLE[base] ?: return base
            return row[tone.index]
        }

        fun toneForKey(c: Char): Tone? = when (c) {
            's' -> Tone.ACUTE
            'f' -> Tone.GRAVE
            'r' -> Tone.HOOK
            'x' -> Tone.TILDE
            'j' -> Tone.DOT
            else -> null
        }
    }
}
