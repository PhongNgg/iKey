package com.ioskeyboard.vn

/**
 * Pure Vietnamese Telex IME engine with automatic English/non-Vietnamese syllable restore.
 *
 * When a typed word violates Vietnamese syllable structure (e.g. "render", "enter", "server",
 * "folder", "voice", "pressed", "bottom", "margin", "google", "android"), the engine
 * automatically restores the exact raw keystrokes so English words are never mangled.
 */
class TelexEngine {

    enum class Tone(val index: Int) {
        NONE(0),
        ACUTE(1),    // s - sắc
        GRAVE(2),    // f - huyền
        HOOK(3),     // r - hỏi
        TILDE(4),    // x - ngã
        DOT(5)       // j - nặng
    }

    data class TelexUpdate(
        val deleteBeforeCursor: Int,
        val commitText: String
    )

    private data class CharEntry(
        var base: Char,
        var isUpper: Boolean
    )

    private val entries = mutableListOf<CharEntry>()
    private val rawKeys = mutableListOf<Char>()
    private var currentTone: Tone = Tone.NONE
    private var lastRendered: String = ""

    private val escapedModifiers = mutableSetOf<Char>()
    private var escapedTone: Boolean = false
    private var autoConvertedOFromUwo: Boolean = false
    private var isRawMode: Boolean = false

    val currentWord: String
        get() = lastRendered

    fun reset() {
        entries.clear()
        rawKeys.clear()
        currentTone = Tone.NONE
        lastRendered = ""
        escapedModifiers.clear()
        escapedTone = false
        autoConvertedOFromUwo = false
        isRawMode = false
    }

    fun isEmpty(): Boolean = rawKeys.isEmpty()

    fun processLetter(ch: Char): TelexUpdate {
        val prevLen = lastRendered.length
        rawKeys.add(ch)

        if (isRawMode) {
            return buildRawUpdate(prevLen)
        }

        val lower = ch.lowercaseChar()
        val isUpper = ch.isUpperCase()

        // 1. Handle 'z' (remove tone)
        if (lower == 'z' && currentTone != Tone.NONE && !escapedTone) {
            currentTone = Tone.NONE
            return finalizeVietnameseOrRestore(prevLen)
        }

        // 2. Handle tone keys: s, f, r, x, j
        val toneFromKey = toneForKey(lower)
        if (toneFromKey != null && hasVowel() && !escapedTone) {
            if (currentTone == toneFromKey) {
                currentTone = Tone.NONE
                escapedTone = true
                entries.add(CharEntry(lower, isUpper))
                return finalizeVietnameseOrRestore(prevLen)
            } else {
                currentTone = toneFromKey
                return finalizeVietnameseOrRestore(prevLen)
            }
        }

        // 3. Handle 'd' -> 'đ' (or undo 'đ' -> 'dd')
        if (lower == 'd' && !escapedModifiers.contains('d')) {
            val dIdx = entries.indexOfFirst { it.base == 'd' || it.base == 'đ' }
            if (dIdx == 0) {
                val target = entries[0]
                if (target.base == 'd') {
                    target.base = 'đ'
                    return finalizeVietnameseOrRestore(prevLen)
                } else if (target.base == 'đ') {
                    target.base = 'd'
                    escapedModifiers.add('d')
                    entries.add(CharEntry('d', isUpper))
                    return finalizeVietnameseOrRestore(prevLen)
                }
            }
        }

        // 4. Handle circumflex keys: a->â, e->ê, o->ô (or undo)
        if ((lower == 'a' || lower == 'e' || lower == 'o') && !escapedModifiers.contains(lower)) {
            val circumflex = when (lower) {
                'a' -> 'â'
                'e' -> 'ê'
                else -> 'ô'
            }
            val idx = entries.indexOfLast { it.base == lower || it.base == circumflex }
            if (idx >= 0) {
                val target = entries[idx]
                if (target.base == lower) {
                    target.base = circumflex
                    return finalizeVietnameseOrRestore(prevLen)
                } else if (target.base == circumflex) {
                    target.base = lower
                    escapedModifiers.add(lower)
                    entries.add(CharEntry(lower, isUpper))
                    return finalizeVietnameseOrRestore(prevLen)
                }
            }
        }

        // 5. Handle 'w' -> ă, ơ, ư, ươ, or standalone ư (or undo)
        if (lower == 'w' && !escapedModifiers.contains('w')) {
            val uoIdx = findUoPairIndex()
            if (uoIdx >= 0) {
                val uEntry = entries[uoIdx]
                val oEntry = entries[uoIdx + 1]
                if (uEntry.base == 'u' && oEntry.base == 'o') {
                    uEntry.base = 'ư'
                    oEntry.base = 'ơ'
                    return finalizeVietnameseOrRestore(prevLen)
                } else if (uEntry.base == 'ư' && oEntry.base == 'ơ') {
                    if (autoConvertedOFromUwo) {
                        autoConvertedOFromUwo = false
                        return finalizeVietnameseOrRestore(prevLen)
                    }
                    uEntry.base = 'u'
                    oEntry.base = 'o'
                    escapedModifiers.add('w')
                    entries.add(CharEntry('w', isUpper))
                    return finalizeVietnameseOrRestore(prevLen)
                } else if (uEntry.base == 'u' && oEntry.base == 'ơ') {
                    uEntry.base = 'ư'
                    return finalizeVietnameseOrRestore(prevLen)
                } else if (uEntry.base == 'ư' && oEntry.base == 'o') {
                    oEntry.base = 'ơ'
                    return finalizeVietnameseOrRestore(prevLen)
                }
            }

            val modIdx = findLastWModifiableVowel()
            if (modIdx >= 0) {
                val target = entries[modIdx]
                when (target.base) {
                    'a' -> { target.base = 'ă'; return finalizeVietnameseOrRestore(prevLen) }
                    'o' -> { target.base = 'ơ'; return finalizeVietnameseOrRestore(prevLen) }
                    'u' -> { target.base = 'ư'; return finalizeVietnameseOrRestore(prevLen) }
                    'ă' -> {
                        target.base = 'a'
                        escapedModifiers.add('w')
                        entries.add(CharEntry('w', isUpper))
                        return finalizeVietnameseOrRestore(prevLen)
                    }
                    'ơ' -> {
                        target.base = 'o'
                        escapedModifiers.add('w')
                        entries.add(CharEntry('w', isUpper))
                        return finalizeVietnameseOrRestore(prevLen)
                    }
                    'ư' -> {
                        if (entries.size == 1 || (modIdx == entries.lastIndex && isConsonantOnlyBefore(modIdx))) {
                            target.base = 'w'
                            escapedModifiers.add('w')
                            return finalizeVietnameseOrRestore(prevLen)
                        } else {
                            target.base = 'u'
                            escapedModifiers.add('w')
                            entries.add(CharEntry('w', isUpper))
                            return finalizeVietnameseOrRestore(prevLen)
                        }
                    }
                }
            } else {
                entries.add(CharEntry('ư', isUpper))
                return finalizeVietnameseOrRestore(prevLen)
            }
        }

        // 6. Regular letter append
        entries.add(CharEntry(lower, isUpper))
        autoFixUwoCompound()
        return finalizeVietnameseOrRestore(prevLen)
    }

    fun processBackspace(): TelexUpdate? {
        if (rawKeys.isEmpty()) return null
        val prevLen = lastRendered.length

        if (isRawMode) {
            rawKeys.removeAt(rawKeys.lastIndex)
            if (rawKeys.isEmpty()) {
                reset()
                return TelexUpdate(deleteBeforeCursor = prevLen, commitText = "")
            }
            return buildRawUpdate(prevLen)
        }

        if (entries.isEmpty()) return null
        entries.removeAt(entries.lastIndex)
        if (rawKeys.isNotEmpty()) {
            rawKeys.removeAt(rawKeys.lastIndex)
        }
        if (entries.isEmpty()) {
            reset()
            return TelexUpdate(deleteBeforeCursor = prevLen, commitText = "")
        }
        if (!hasVowel()) {
            currentTone = Tone.NONE
        }
        escapedModifiers.clear()
        escapedTone = false
        autoConvertedOFromUwo = false
        return buildUpdate(prevLen)
    }

    private fun finalizeVietnameseOrRestore(prevLen: Int): TelexUpdate {
        if (escapedTone || escapedModifiers.isNotEmpty()) {
            // User explicitly undid a Telex modifier/tone (e.g. "off", "ass", "aaa", "ww")
            // Keep the undone literal text intact
            return buildUpdate(prevLen)
        }
        if (!isValidVietnameseSyllable()) {
            isRawMode = true
            return buildRawUpdate(prevLen)
        }
        return buildUpdate(prevLen)
    }

    private fun buildRawUpdate(prevLen: Int): TelexUpdate {
        val raw = String(rawKeys.toCharArray())
        lastRendered = raw
        return TelexUpdate(deleteBeforeCursor = prevLen, commitText = raw)
    }

    /**
     * Validates that the current `entries` conform to Vietnamese syllable phonotactics:
     *   [Valid Initial] + [Valid Vowel Nucleus] + [Valid Final Coda]
     * Rejects invalid clusters (e.g. "rend", "ent", "serv", "goog", "voic", "home", "pr", "sp")
     * so English words auto-restore to raw keystrokes.
     */
    private fun isValidVietnameseSyllable(): Boolean {
        if (entries.isEmpty()) return true
        val n = entries.size

        // Find first vowel index
        var vStart = -1
        for (i in 0 until n) {
            if (isVowelBase(entries[i].base)) {
                vStart = i
                break
            }
        }

        // Consonants only so far (still typing initial consonant)
        if (vStart == -1) {
            val init = buildBaseString(0, n)
            return VALID_INITIALS.contains(init)
        }

        // Handle "qu" + vowel and "gi" + vowel as part of initial consonant
        var actualVStart = vStart
        if (vStart == 1 && entries[0].base == 'q' && entries[1].base == 'u' && n > 2 && isVowelBase(entries[2].base)) {
            actualVStart = 2
        } else if (vStart == 1 && entries[0].base == 'g' && entries[1].base == 'i' && n > 2 && isVowelBase(entries[2].base)) {
            actualVStart = 2
        }

        val initial = buildBaseString(0, actualVStart)
        if (!VALID_INITIALS.contains(initial)) return false

        // Scan contiguous vowel nucleus
        var vEnd = actualVStart
        while (vEnd < n && isVowelBase(entries[vEnd].base)) {
            vEnd++
        }

        // Any vowel appearing after a final consonant is impossible in Vietnamese (e.g. "home", "gemini")
        for (i in vEnd until n) {
            if (isVowelBase(entries[i].base)) return false
        }

        val nucleus = buildBaseString(actualVStart, vEnd)
        val coda = buildBaseString(vEnd, n)

        if (!VALID_CODAS.contains(coda)) return false

        if (nucleus.length == 1) {
            return true
        }
        if (nucleus.length == 2) {
            if (!VALID_VOWEL_2.contains(nucleus)) return false
            if (coda.isNotEmpty() && OPEN_ONLY_VOWEL_2.contains(nucleus)) return false
            return true
        }
        if (nucleus.length == 3) {
            if (!VALID_VOWEL_3.contains(nucleus)) return false
            // Only "uyê" / "uye" can take a final consonant among 3-vowel nuclei (e.g. "quyền", "tuyệt")
            if (coda.isNotEmpty() && nucleus != "uyê" && nucleus != "uye") return false
            return true
        }

        return false
    }

    private fun buildBaseString(from: Int, to: Int): String {
        val sb = StringBuilder(to - from)
        for (i in from until to) {
            sb.append(entries[i].base)
        }
        return sb.toString()
    }

    private fun autoFixUwoCompound() {
        for (i in 0 until entries.size - 1) {
            if (entries[i].base == 'ư' && entries[i + 1].base == 'o') {
                val isQu = i > 0 && entries[i - 1].base == 'q'
                if (!isQu) {
                    entries[i + 1].base = 'ơ'
                    autoConvertedOFromUwo = true
                }
            }
        }
    }

    private fun isConsonantOnlyBefore(idx: Int): Boolean {
        for (i in 0 until idx) {
            if (isVowelBase(entries[i].base)) return false
        }
        return true
    }

    private fun findUoPairIndex(): Int {
        for (i in 0 until entries.size - 1) {
            val c1 = entries[i].base
            val c2 = entries[i + 1].base
            val isQu = i > 0 && entries[i - 1].base == 'q'
            if (!isQu && (c1 == 'u' || c1 == 'ư') && (c2 == 'o' || c2 == 'ơ')) {
                return i
            }
        }
        return -1
    }

    private fun findLastWModifiableVowel(): Int {
        for (i in entries.indices.reversed()) {
            val c = entries[i].base
            if (c == 'a' || c == 'ă' || c == 'o' || c == 'ơ' || c == 'u' || c == 'ư') {
                if (c == 'u' && i > 0 && entries[i - 1].base == 'q' && i < entries.lastIndex && isVowelBase(entries[i + 1].base)) {
                    continue
                }
                if (c == 'a' && i > 0 && (entries[i - 1].base == 'u' || entries[i - 1].base == 'ư')) {
                    val isQu = i >= 2 && entries[i - 2].base == 'q'
                    if (!isQu) continue
                }
                return i
            }
        }
        return -1
    }

    private fun hasVowel(): Boolean = entries.any { isVowelBase(it.base) }

    private fun buildUpdate(prevLen: Int): TelexUpdate {
        val rendered = render()
        lastRendered = rendered
        return TelexUpdate(deleteBeforeCursor = prevLen, commitText = rendered)
    }

    private fun render(): String {
        if (entries.isEmpty()) return ""
        val toneIdx = if (currentTone != Tone.NONE) findToneTargetIndex() else -1
        val sb = StringBuilder(entries.size)
        for (i in entries.indices) {
            val entry = entries[i]
            val ch = if (i == toneIdx) applyTone(entry.base, currentTone) else entry.base
            sb.append(if (entry.isUpper) ch.uppercaseChar() else ch)
        }
        return sb.toString()
    }

    private fun findToneTargetIndex(): Int {
        val vowelIndices = mutableListOf<Int>()
        for (i in entries.indices) {
            if (isVowelBase(entries[i].base)) {
                vowelIndices.add(i)
            }
        }
        if (vowelIndices.isEmpty()) return -1

        val effectiveVowels = vowelIndices.filterNot { idx ->
            val c = entries[idx].base
            val hasNextVowel = vowelIndices.any { it > idx }
            (c == 'u' && idx == 1 && entries[0].base == 'q' && hasNextVowel) ||
                (c == 'i' && idx == 1 && entries[0].base == 'g' && hasNextVowel)
        }.ifEmpty { vowelIndices }

        if (effectiveVowels.size == 1) return effectiveVowels[0]

        for (idx in effectiveVowels) {
            if (entries[idx].base == 'ơ') return idx
        }
        val priorityModified = effectiveVowels.firstOrNull { entries[it].base in setOf('ê', 'ô', 'â', 'ă') }
        if (priorityModified != null) return priorityModified

        val lastVowelIdx = effectiveVowels.last()
        val hasFinalConsonant = lastVowelIdx < entries.lastIndex

        if (effectiveVowels.size >= 3) {
            return effectiveVowels[1]
        }

        val v1 = entries[effectiveVowels[0]].base
        val v2 = entries[effectiveVowels[1]].base
        if (hasFinalConsonant) {
            return effectiveVowels[1]
        }

        val pair = "$v1$v2"
        return if (pair == "oa" || pair == "oe" || pair == "uy") {
            effectiveVowels[1]
        } else {
            effectiveVowels[0]
        }
    }

    companion object {
        private val VOWEL_TABLE: Map<Char, String> = mapOf(
            'a' to "aáàảãạ",
            'ă' to "ăắằẳẵặ",
            'â' to "âấầẩẫậ",
            'e' to "eéèẻẽẹ",
            'ê' to "êếềểễệ",
            'i' to "iíìỉĩị",
            'o' to "oóòỏõọ",
            'ô' to "ôốồổỗộ",
            'ơ' to "ơớờởỡợ",
            'u' to "uúùủũụ",
            'ư' to "ưứừửữự",
            'y' to "yýỳỷỹỵ"
        )

        private val VALID_INITIALS = setOf(
            "", "b", "c", "ch", "d", "đ", "g", "gh", "gi", "h", "k", "kh",
            "l", "m", "n", "ng", "ngh", "nh", "p", "ph", "q", "qu", "r",
            "s", "t", "th", "tr", "v", "x"
        )

        private val VALID_CODAS = setOf(
            "", "c", "ch", "m", "n", "ng", "nh", "p", "t"
        )

        private val VALID_VOWEL_2 = setOf(
            "ai", "ao", "au", "ay", "âu", "ây",
            "eo", "eu", "êu",
            "ia", "ie", "iê", "iu",
            "oa", "oă", "oe", "oi", "ôi", "ơi",
            "ua", "uă", "uâ", "ue", "uê", "ui", "uo", "uô", "uơ",
            "ưa", "ưi", "ươ", "ưu", "uy",
            "ye", "yê"
        )

        // 2-vowel clusters that can NEVER be followed by a final consonant in Vietnamese
        private val OPEN_ONLY_VOWEL_2 = setOf(
            "ai", "ao", "au", "ay", "âu", "ây",
            "eo", "eu", "êu",
            "ia", "iu",
            "oi", "ôi", "ơi",
            "ui", "ưa", "ưi", "ưu"
        )

        private val VALID_VOWEL_3 = setOf(
            "ieu", "iêu",
            "oai", "oay", "oao", "oeo",
            "uai", "uay", "uây", "uoi", "uôi", "ươi", "uou", "ươu",
            "uya", "uye", "uyê", "uyu",
            "yeu", "yêu"
        )

        fun isVowelBase(c: Char): Boolean = VOWEL_TABLE.containsKey(c)

        fun applyTone(base: Char, tone: Tone): Char {
            val row = VOWEL_TABLE[base] ?: return base
            return row[tone.index]
        }

        fun toneForKey(c: Char): Tone? = when (c) {
            's' -> Tone.ACUTE
            'f' -> Tone.GRAVE
            'r' -> Tone.HOOK
            'x' -> Tone.TILDE
            'j' -> Tone.DOT
            else -> null
        }
    }
}
