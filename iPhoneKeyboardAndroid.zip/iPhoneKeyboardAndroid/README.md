# iKey VN — Bàn phím kiểu iPhone cho Android (Tiếng Việt Telex)

Ứng dụng bàn phím Android (IME) viết bằng Kotlin, mô phỏng kích thước, tỉ lệ phím, giao diện Sáng/Tối và cảm giác gõ của bàn phím iPhone, tích hợp bộ gõ **Tiếng Việt Telex thuần** (không thanh gợi ý, không tự động sửa lỗi, không swipe).

## Tính năng chính
- **Bố cục & kích thước chuẩn iPhone**: Hàng phím số `1–0` (bật/tắt được trong cài đặt) + hàng 10 / 9 (thụt lề 0.5 phím) / 7 phím, phím bo góc `5dp` kèm đổ bóng đáy `1dp`, chiều cao phím chuẩn `42dp` (tùy chỉnh được `38dp / 42dp / 46dp`).
- **Giao diện Sáng / Tối (Light & Dark)**: Tự động theo hệ thống hoặc chọn cố định.
- **Bộ gõ Tiếng Việt Telex thuần**:
  - Hỗ trợ đầy đủ `aw -> ă`, `aa -> â`, `ee -> ê`, `oo -> ô`, `ow -> ơ`, `uw -> ư`, `dd -> đ`, `w -> ư`, tổ hợp `uow -> ươ` (`duowng -> dương`, `nguowif -> người`).
  - Bỏ dấu tự do `s / f / r / x / j`, xóa dấu bằng `z`, tự chỉnh vị trí dấu khi gõ tiếp (`hoaf -> hòa`, `hoafn -> hoàn`).
  - Gõ lặp để hoàn tác khi gõ tiếng Anh (`off -> of`, `ass -> as`, `aaa -> aa`, `ww -> w`).
- **Thao tác kiểu iOS**:
  - Hiệu ứng phóng to phím khi chạm (Key Popup).
  - Giữ phím `dấu cách` rồi rê ngang để di chuyển con trỏ (Trackpad).
  - Nhấn đúp `dấu cách` để chèn `. `.
  - Phím `Shift` (1 chạm viết hoa, 2 chạm bật Caps Lock) và nhấn giữ `Backspace` để xóa nhanh.
  - Phím `Return` tự đổi nhãn (`nhập`, `tìm`, `gửi`, `đi`, `xong`) và đổi màu xanh iOS `#007AFF` theo ngữ cảnh.
  - Phím quả cầu (`🌐`): chạm để chuyển nhanh **Tiếng Việt (Telex) ↔ English**, nhấn giữ để đổi sang bàn phím khác.
  - Bảng Emoji phân loại 5 nhóm.

## Cách xuất file APK cài lên điện thoại

### Cách 1: Build bằng Android Studio (nhanh nhất trên máy tính)
1. Giải nén file `iPhoneKeyboardAndroid.zip`.
2. Mở **Android Studio** → chọn **Open** → trỏ tới thư mục `iPhoneKeyboardAndroid`.
3. Đợi Gradle tự đồng bộ (cần kết nối mạng lần đầu).
4. Chọn menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. File cài đặt nằm ở `app/build/outputs/apk/debug/app-debug.apk`. Chép sang điện thoại Android và cài đặt.

### Cách 2: Tự động build APK trên GitHub (không cần cài Android Studio)
1. Tạo một repository mới trên GitHub và đẩy toàn bộ thư mục dự án lên.
2. Vào tab **Actions** → chọn workflow **Build Debug APK** → bấm **Run workflow**.
3. Sau ~2 phút, tải file **iPhoneKeyboardVN-debug-apk** trong mục **Artifacts** về điện thoại và cài đặt.

## Cài đặt & sử dụng trên Android
1. Mở ứng dụng **iKey VN** sau khi cài APK.
2. Bấm **Mở cài đặt & bật iKey VN** → bật công tắc **iKey VN**.
3. Quay lại app, bấm **Chọn iKey VN làm bàn phím mặc định** → chọn **iKey VN**.
4. Gõ thử trực tiếp trong ô kiểm tra và tùy chỉnh giao diện / chiều cao phím / rung / âm thanh theo ý thích.
